/*amd /ui/textArea/textAreaAppendScrollMove.xml 3003 fd4686b311e98b18879d26e6c322eeb4f576d837a5b4df8bd466a5ca38b0b4c8 */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',E:[{T:1,N:'w2:type',E:[{T:3,text:'DEFAULT'}]},{T:1,N:'w2:buildDate'},{T:1,N:'xf:model',E:[{T:1,N:'w2:dataCollection',A:{baseNode:'map'},E:[{T:1,N:'w2:dataList',A:{baseNode:'list',repeatNode:'map',id:'dlt_memberList',saveRemovedData:'true','ev:oncelldatachange':''},E:[{T:1,N:'w2:columnInfo',E:[{T:1,N:'w2:column',A:{id:'id',name:'아이디',dataType:'text'}},{T:1,N:'w2:column',A:{id:'name',name:'성명',dataType:'text'}},{T:1,N:'w2:column',A:{id:'tel',name:'연락처',dataType:'text'}},{T:1,N:'w2:column',A:{id:'region',name:'지역',dataType:'text'}}]},{T:1,N:'w2:data',A:{use:'true'},E:[{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0001'}]},{T:1,N:'name',E:[{T:4,cdata:'홍길동'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2323-4323'}]},{T:1,N:'region',E:[{T:4,cdata:'서울'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0002'}]},{T:1,N:'name',E:[{T:4,cdata:'허균'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2444-2312'}]},{T:1,N:'region',E:[{T:4,cdata:'인천'}]}]}]}]}]},{T:1,N:'w2:workflowCollection'}]},{T:1,N:'script',A:{type:'text/javascript',lazy:'false'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){scwin.onpageload = function () {
};

scwin.btn_execute_onclick = function (e) {
	var strLog = JSON.stringify(dlt_memberList.getAllJSON(), null, '\t');

	scwin.printExampleLog(strLog, txa_log, true);
};

scwin.printExampleLog = function (argStrLog, argCmpTarget) {

	//textarea에 출력된 기존 데이터 추출.
	var strPreData = argCmpTarget.getValue();
	
	if (strPreData !== "") { 
		strPreData += "\n";
	}

	// 기존 데이터에 추가하여 출력
	argCmpTarget.setValue(strPreData + "[" + new Date().toLocaleTimeString("sv-SE") + "] *******************************************\n" + argStrLog);

	// textarea 스크롤 바닥으로 옮기기.
	scwin.scrollToBottom(argCmpTarget);
};



scwin.scrollToBottom = function (argCmp) {
	var eleObj;
	eleObj = argCmp.render;
	if (!eleObj) {
		console.error("웹스퀘어 객체가 아닙니다.");
		return;
	}
	eleObj.scrollTop = eleObj.scrollHeight;
};


}}}]}]},{T:1,N:'body',A:{'ev:onpageload':'scwin.onpageload'},E:[{T:1,N:'xf:group',A:{id:'',style:'padding:10px'},E:[{T:1,N:'xf:group',A:{style:'width: 100%;height: 45px;',id:''},E:[{T:1,N:'w2:textbox',A:{style:'width:50%;height:23px;padding:10px;font-size:18px;font-weight:bold;float:left;',id:'',label:'TextArea Append & Scroll Move'}},{T:1,N:'xf:trigger',A:{'ev:onclick':'scwin.btn_execute_onclick',style:'width: 80px;height: 23px;float:right;margin-top: 10px;margin-right: 10px;',id:'btn_execute',type:'button'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'실행'}]}]}]},{T:1,N:'xf:group',A:{style:'width:100%;height:500px;',id:'grp_group1'},E:[{T:1,N:'xf:textarea',A:{id:'txa_log',style:'width: 100%;height: 100%;'}}]}]}]}]}]})