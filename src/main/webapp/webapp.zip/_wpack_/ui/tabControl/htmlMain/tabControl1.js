/*amd /ui/tabControl/htmlMain/tabControl1.xml 2500 1f8318725ce951a439f126bdb34c34786e07ea2c4ea297c902a3e8cdfd35fb1d */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',A:{},E:[{T:1,N:'w2:type',E:[{T:3,text:'DEFAULT'}]},{T:1,N:'w2:buildDate'},{T:1,N:'xf:model',E:[{T:1,N:'w2:dataCollection',A:{baseNode:'map'}},{T:1,N:'w2:workflowCollection'}]},{T:1,N:'script',A:{type:'text/javascript',lazy:'false'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){
        
	scwin.onpageload = function() {
	};
	
	scwin.onpageunload = function() {
		
	};

	scwin.tabIndex = 0;
	
	scwin.addTab = function(e) {
		scwin.tabIndex++;
		var tabOpt = {
			label : "WFrame - " + scwin.tabIndex,
			closable : true,
		};

		var contOpt = {
			frameMode : "wframe",
			src : "tab" + ((scwin.tabIndex % 2) + 1) + ".xml",
			title : "WFrame - " + scwin.tabIndex
		};

		tac_tabControl1.addTab(scwin.tabIndex, tabOpt, contOpt);
		tac_tabControl1.setSelectedTabIndex(tac_tabControl1.getTabCount()-1);
	};
	
	scwin.btn_srcDownload_onclick = function(e) {
		window.open("/util/downloadZipFile?filePath=/ui/sample/tabControl/htmlMain&fileName=htmlMain.zip");
	};
	
}}}]}]},{T:1,N:'body',A:{'ev:onpageload':'scwin.onpageload','ev:onpageunload':'scwin.onpageunload'},E:[{T:1,N:'xf:group',A:{id:'',style:'padding:10px;height: 579px;'},E:[{T:1,N:'xf:group',A:{id:'',style:'width: 100%;height: 45px;'},E:[{T:1,N:'w2:textbox',A:{id:'',label:'WebSquare5 프레임워크 영역',style:'width:45%;height:23px;padding:10px;font-size:18px;font-weight:bold;float:left;'}},{T:1,N:'xf:group',A:{id:'',style:'width:45%;height:23px;padding:10px;font-size:18px;font-weight:bold;float:right;'},E:[{T:1,N:'xf:trigger',A:{id:'btn_srcDownload',style:'width:106px;height:23px;float:right;',type:'button','ev:onclick':'scwin.btn_srcDownload_onclick'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'소스 다운로드'}]}]}]}]},{T:1,N:'xf:group',A:{style:'width:100%;height:444px;',id:'grp_group1'},E:[{T:1,N:'w2:tabControl',A:{useTabKeyOnly:'true',id:'tac_tabControl1',useMoveNextTabFocus:'false',useConfirmMessage:'false',confirmTrueAction:'exist',confirmFalseAction:'new',alwaysDraw:'false',style:'width: 100%;height: 530px;',tabMove:'true',tabScroll:'true'},E:[{T:1,N:'w2:tabs',A:{disabled:'false',style:'width:100px;height:30px;',id:'tabs1',label:'WFrame - 1'}},{T:1,N:'w2:content',A:{alwaysDraw:'false',style:'height:500px;',id:'content1',src:'tab1.xml'}}]}]}]}]}]}]})