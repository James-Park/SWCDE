/*amd /ui/widgetContainer/customButton/widget1.xml 7139 d84b661e4c7b5de924ec75a12e6498ee6bc1b4d225e0380a0299ada1adcfd764 */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',E:[{T:1,N:'w2:type',E:[{T:3,text:'DEFAULT'}]},{T:1,N:'w2:buildDate'},{T:1,N:'xf:model',E:[{T:1,N:'w2:dataCollection',A:{baseNode:'map'},E:[{T:1,N:'w2:dataList',A:{baseNode:'list',repeatNode:'map',id:'dlt_memberList',saveRemovedData:'true','ev:oncelldatachange':''},E:[{T:1,N:'w2:columnInfo',E:[{T:1,N:'w2:column',A:{id:'id',name:'아이디',dataType:'text'}},{T:1,N:'w2:column',A:{id:'name',name:'성명',dataType:'text'}},{T:1,N:'w2:column',A:{id:'tel',name:'연락처',dataType:'text'}},{T:1,N:'w2:column',A:{id:'region',name:'지역',dataType:'text'}}]},{T:1,N:'w2:data',A:{use:'true'},E:[{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0001'}]},{T:1,N:'name',E:[{T:4,cdata:'홍길동'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2323-4323'}]},{T:1,N:'region',E:[{T:4,cdata:'서울'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0002'}]},{T:1,N:'name',E:[{T:4,cdata:'허균'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2444-2312'}]},{T:1,N:'region',E:[{T:4,cdata:'인천'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0001'}]},{T:1,N:'name',E:[{T:4,cdata:'홍길동1'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2323-4323'}]},{T:1,N:'region',E:[{T:4,cdata:'서울'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0002'}]},{T:1,N:'name',E:[{T:4,cdata:'허균1'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2444-2312'}]},{T:1,N:'region',E:[{T:4,cdata:'인천'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0001'}]},{T:1,N:'name',E:[{T:4,cdata:'홍길동2'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2323-4323'}]},{T:1,N:'region',E:[{T:4,cdata:'서울'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0002'}]},{T:1,N:'name',E:[{T:4,cdata:'허균2'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2444-2312'}]},{T:1,N:'region',E:[{T:4,cdata:'인천'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0001'}]},{T:1,N:'name',E:[{T:4,cdata:'홍길동3'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2323-4323'}]},{T:1,N:'region',E:[{T:4,cdata:'서울'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0002'}]},{T:1,N:'name',E:[{T:4,cdata:'허균3'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2444-2312'}]},{T:1,N:'region',E:[{T:4,cdata:'인천'}]}]}]}]}]},{T:1,N:'w2:workflowCollection'}]},{T:1,N:'script',A:{type:'text/javascript',lazy:'false'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){
	scwin.onpageload = function() {
	};

	scwin.openPage = function(buttonId) {
		if (buttonId == "custombtn1") {
			$p.top().scwin.openMenu(buttonId, "menu1.xml");
		} else if (buttonId == "custombtn2") {
			$p.top().scwin.openMenu(buttonId, "menu2.xml");
		}
	};

	scwin.grd_gridView1_oncontextopen = function(row, col) {
		// return false; // 컨텍스트 메뉴를 보여주지 않습니다.
		// return { hideSystemMenu: false } // 전체 시스템 메뉴를 보여주지 않습니다.
		return {
			// hideSystemMenu 옵션을 설정하면 해당 GridView 기본 Contenxt Menu가 보이지 않도록 설정됨
			// - ColumnHide : 선택 컬럼 숨기기
			// - ColumnShowAll : 전체 컬럼 숨기기 해제
			// - ColumnFix : 선택 컬럼 틀고정
			// - ColumnUnfixAll : 전체 컬럼 틀고정 취소
			// - ColumnAdjustWidth : 선택 컬럼 크기 자동 맞추기
			// - ColumnAdjustAuto : 전체 컬럼 크기 자동 맞추기
			// - FoldAll : 전체 그룹 접기
			// - UnfoldAll : 전체 그룹 펼치기
			// - Group : 전체 그룹 해제
			// - Ungroup : 선택 컬럼 그룹 해제
			// - UngroupAll : 선택 컬럼 그룹
			// - ColumnAdjustAutoNone : 전체 컬럼 자동 맞추기 해제
			hideSystemMenu : [ "ColumnHide", "ColumnShowAll", "ColumnFix", "ColumnUnfixAll", "ColumnAdjustWidth", "ColumnAdjustAuto", "FoldAll", "UnfoldAll", "Group", "Ungroup", "UngroupAll", "ColumnAdjustAutoNone" ],
			appendMenu : [{
				label : "Menu1 화면 오픈하기", // 사용자 메뉴의 표시 문자열
				userMenuId : "custombtn1", // 사용자 메뉴의 id, 해당 컨텍스트 메뉴가 클릭될때, 입력값으로 전달됨
				className : "userMenu" // 사용자 메뉴의 스타일 클래스 이름 
			}, {
				label : "Menu2 화면 오픈하기", // 사용자 메뉴의 표시 문자열
				userMenuId : "custombtn2", // 사용자 메뉴의 id, 해당 컨텍스트 메뉴가 클릭될때, 입력값으로 전달됨
				className : "userMenu" // 사용자 메뉴의 스타일 클래스 이름 
			}], // 시스템 메뉴 아래에, 사용자 메뉴를 추가합니다.
		};
	};

	// 컨텍스트 메뉴가 클릭 된 후 호출됩니다. 시스템 메뉴는 시스템 기능이 완료된 후 호출됩니다.
	scwin.grd_gridView1_oncontextclick = function(row, col, userMenuId, isSystemMenu, systemMenu) {
		if (isSystemMenu == false) {
			scwin.openPage(userMenuId);
		}
	};

	scwin.onpageunload = function() {

	};

}}}]}]},{T:1,N:'body',A:{'ev:onpageload':'scwin.onpageload','ev:onpageunload':'scwin.onpageunload'},E:[{T:1,N:'xf:group',A:{style:'padding:10px;',id:''},E:[{T:1,N:'xf:group',A:{style:'width: 100%;height:40px;float:left;',id:'',class:''},E:[{T:1,N:'w2:textbox',A:{style:'height: 23px;font-size:20px;float:left;margin-top:5px;margin-left:5px;font-weight: bold',label:'Widget Contents',id:''}}]},{T:1,N:'w2:gridView',A:{id:'grd_gridView1',ignoreToggleOnDisabled:'false',useShiftKey:'true',style:'width:100%;height:97px;',scrollByColumn:'false',defaultCellHeight:'20',scrollByColumnAdaptive:'false',summaryAuto:'false',summaryOnlyAuto:'false',applyAllColumnStyle:'false',dataList:'data:dlt_memberList',ignoreCellClick:'false',autoFit:'allColumn',visibleRowNum:'4',contextMenu:'true','ev:oncontextopen':'scwin.grd_gridView1_oncontextopen','ev:oncontextclick':'scwin.grd_gridView1_oncontextclick'},E:[{T:1,N:'w2:caption',A:{style:'',id:'caption1',value:'this is a grid caption.'}},{T:1,N:'w2:header',A:{style:'',id:'header1'},E:[{T:1,N:'w2:row',A:{style:'',id:'row1'},E:[{T:1,N:'w2:column',A:{width:'135',inputType:'text',style:'',id:'column7',value:'아이디',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'113',inputType:'text',style:'',id:'column5',value:'성명',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'114',inputType:'text',style:'',id:'column3',value:'연락처',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'129',inputType:'text',style:'',id:'column1',value:'지역',blockSelect:'false',displayMode:'label'}}]}]},{T:1,N:'w2:gBody',A:{style:'',id:'gBody1'},E:[{T:1,N:'w2:row',A:{style:'',id:'row2'},E:[{T:1,N:'w2:column',A:{width:'135',inputType:'text',style:'',id:'id',value:'',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'113',inputType:'text',style:'',id:'name',value:'',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'114',inputType:'text',style:'',id:'tel',value:'',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'129',inputType:'text',style:'',id:'region',value:'',blockSelect:'false',displayMode:'label'}}]}]}]}]}]}]}]})