/*amd /ui/widgetContainer/customButton/menu1.xml 1556 cd8f54b3a593b1ff268ebb359406ba9886b0da09026c6dda3173fbcaea749f79 */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',E:[{T:1,N:'w2:type',E:[{T:3,text:'DEFAULT'}]},{T:1,N:'w2:buildDate'},{T:1,N:'xf:model',E:[{T:1,N:'w2:dataCollection',A:{baseNode:'map'}},{T:1,N:'w2:workflowCollection'}]},{T:1,N:'script',A:{type:'text/javascript',lazy:'false'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){
        
	scwin.onpageload = function() {
	};
	
	scwin.onpageunload = function() {
		
	};


}}}]}]},{T:1,N:'body',A:{'ev:onpageload':'scwin.onpageload','ev:onpageunload':'scwin.onpageunload'},E:[{T:1,N:'xf:group',A:{id:'',style:'padding:10px'},E:[{T:1,N:'xf:group',A:{style:'width: 100%;height: 45px;',id:''},E:[{T:1,N:'w2:textbox',A:{style:'width:50%;height:23px;padding:10px;font-size:18px;font-weight:bold;float:left;',id:'',label:'Menu1'}},{T:1,N:'xf:trigger',A:{'ev:onclick':'',style:'width: 80px;height: 23px;float:right;margin-top: 10px;margin-right: 10px;',id:'btn_test',type:'button'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'버튼'}]}]}]},{T:1,N:'xf:group',A:{style:'width:100%;height:600px;',id:'grp_group1'},E:[{T:1,N:'w2:scheduleCalendar',A:{selectable:'false',ioFormat:'yyyyMMdd',eventLimit:'true',id:'',lang:'ko',defaultDate:'',editable:'false',headerRightBtn:'true',titleColumn:'',startColumn:'',dataList:'',style:'width: 100%;height: 600px;',headerLeftBtn:'true',idColumn:'',headerTitle:'true'}}]}]}]}]}]})