/*amd /ui/widgetContainer/customButton/widgetContainer.xml 2951 ea0c7136b317d3ff78ee5324c0cf53d8c32e5e79488586b7f7ca67c5807b8079 */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',E:[{T:1,N:'w2:type',E:[{T:3,text:'DEFAULT'}]},{T:1,N:'w2:buildDate'},{T:1,N:'xf:model',E:[{T:1,N:'w2:dataCollection',A:{baseNode:'map'},E:[{T:1,N:'w2:dataList',A:{id:'dataList1',baseNode:'list',saveRemovedData:'true',repeatNode:'map'},E:[{T:1,N:'w2:columnInfo',E:[{T:1,N:'w2:column',A:{id:'col1',name:'name1',dataType:'text'}},{T:1,N:'w2:column',A:{id:'col2',name:'name2',dataType:'text'}},{T:1,N:'w2:column',A:{id:'col3',name:'name3',dataType:'text'}}]}]}]},{T:1,N:'w2:workflowCollection'}]},{T:1,N:'script',A:{type:'text/javascript',lazy:'false'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){
	scwin.count = 0;

	scwin.onpageload = function() {
	};

	scwin.onpageunload = function() {
	};

	scwin.trigger1_onclick = function(e) {

		var bFormatter = function() {
			return [{
				'id' : 'custombtn1',
				'className' : 'w2widget_btnCustom',
				'isCustom' : true
			}, {
				'id' : 'custombtn2',
				'className' : 'w2widget_btnCustom',
				'isCustom' : true
			}, {
				'useDefault' : 'maximize'
			}, {
				'useDefault' : 'close'
			}];
		};

		var mFormatter = function() {
			return {
				top : 2,
				bottom : 3,
				left : -1,
				right : 0
			};
		}

		var widgetSrc = "widget1.xml";
		widgetContainer1.addWidgets({
			id : "widget" + scwin.count,
			title : "위젯" + scwin.count,
			src : widgetSrc,
			scope : true,
			x : scwin.count % 3,
			y : 0,
			unitWidth : 1,
			unitHeight : 1,
			buttonFormatter : bFormatter,
			maximizeFormatter : mFormatter
		});
		
		scwin.count++;
	};

	scwin.widgetContainer_onclickcustombtn = function(widgetId, btnId) {
		var widgetWindow = widgetContainer1.getWidgetById(widgetId);
		if (typeof widgetWindow.getWindow().scwin.openPage === "function") {
			widgetWindow.getWindow().scwin.openPage(btnId);
		}
	};

}}}]},{T:1,N:'style',A:{type:'text/css'},E:[{T:4,cdata:'.w2widget_btnCustom{background-color:#87ceeb}.w2widget_btnCustom3{width:15px;height:15px;background-color:gray}'}]}]},{T:1,N:'body',A:{'ev:onpageload':'scwin.onpageload','ev:onpageunload':'scwin.onpageunload',style:''},E:[{T:1,N:'xf:group',A:{id:'group1',style:'width:100%;height:600px;',class:''},E:[{T:1,N:'xf:group',A:{id:'',style:'position: relative;height:40px;',class:''},E:[{T:1,N:'xf:trigger',A:{type:'button',id:'trigger1',style:'position: relative;height:25px;width:150px;float: left;','ev:onclick':'scwin.trigger1_onclick'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'addWidget'}]}]}]},{T:1,N:'w2:widgetContainer',A:{id:'widgetContainer1',cols:'3',style:'position:relative;width:100%;height:557px;border:1px solid black;',unitHeightPixel:'200',mode:'pushpull',widgetMove:'true',isCustom:'true','ev:onclickcustombtn':'scwin.widgetContainer_onclickcustombtn'}}]}]}]}]})