/*amd /ui/external/fullCalendar5.7.0/udc/udc_fullCalendar.xml 4526 01c2d6312449d38a821cc0ead0fcb1fe54b87b69b3b86af5acb2b3f8e993dd61 */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',E:[{T:1,N:'w2:type',E:[{T:3,text:'UDC'}]},{T:1,N:'w2:buildDate'},{T:1,N:'w2:model'}]},{T:1,N:'body',E:[{T:1,N:'xf:group',A:{style:'',id:'',pluginName:'udc_fullCalendar'},E:[{T:1,N:'link',A:{rel:'stylesheet',type:'text/css',href:'/ui/SP/externalJS/fullCalendar/js/fullcalendar-5.7.0/lib/main.min.css'}},{T:1,N:'style',A:{type:'text/css'}},{T:1,N:'script',A:{type:'text/javascript',src:'/ui/SP/externalJS/fullCalendar/js/fullcalendar-5.7.0/lib/main.min.js'}},{T:1,N:'script',A:{type:'text/javascript',src:'/ui/SP/externalJS/fullCalendar/js/fullcalendar-5.7.0/lib/moment.min.js'}},{T:1,N:'script',A:{'ev:event':'oncreated(options)',type:'text/javascript'},E:[{T:4,cdata:function(scopeObj,options){with(scopeObj){var udc_obj=WebSquare.util.getComponentById(WebSquare.scope_obj);
				/**
				 * //property handling
				 * $w.log("id:" + options.id);
				 * $w.log("style:" + options.style);
				 * $w.log("class:" + options.class);
				 * $w.log("ref:" + options.ref);
				 *
				 * //event trigger
				*/
				
				udc_obj.init = function() {
					var empCd = $p.top().wfm_side.getWindow().dma_defInfo.get("EMP_CD");
					var calendarEl = document.getElementById("_calDiv");
					var calendar = new FullCalendar.Calendar(calendarEl, {
						initialView: "dayGridMonth",
						locale: "ko",
						googleCalendarApiKey: "AIzaSyDcnW6WejpTOCffshGDDb4neIrXVUA1EAE",
						nowIndicator: true,
						selectable: true,
						headerToolbar: {
							left: "prev,next today",
							center: "title",
							right: "dayGridMonth,timeGridWeek,timeGridDay,listWeek"
						},
						select: function(selectionInfo) {
							
							var inputString = prompt("이벤트 명을 입력해주세요.");
							if (!com.util.isEmpty(inputString)) {
								//calendar.addEvent({ title: inputString, start: selectionInfo.startStr, end: selectionInfo.endStr });
								var setScheduleOption = {
									id : "_sbm_setSchedule",
									action : "/calendar/setScheduleById",
									target : "",
									submitDoneHandler : "",
									isProcessMsg : false
								};
								
								com.sbm.executeDynamic(setScheduleOption, {
									"dma_save" : {
										"EMP_CD" : empCd,
										"TITLE" : inputString,
										"START" : moment(selectionInfo.startStr).format("YYYY-MM-DD hh:mm:ss"),
										"END" : moment(selectionInfo.endStr).format("YYYY-MM-DD hh:mm:ss"),
										"ALL_DAY" : selectionInfo.allDay
									}
								});
							}
						},
						businessHours: {
							daysOfWeek: [1, 2, 3, 4, 5],
							startTime: "09:00",
							endTime: "18:00"
						},
						eventClick: function(eventClickInfo) {
							eventClickInfo.jsEvent.preventDefault();
						},
						eventSources: [
							{
								events: function(info, successCallback, failureCallback) {
									var getScheduleOption = {
										id : "_sbm_getSchedule",
										action : "/calendar/getScheduleById",
										target : "",
										submitDoneHandler : function(e) {
											var result = e.responseJSON.dataList;
//											for(var idx1 = 0; idx1 < result.length; idx1++) {
//												calendar.addEvent({
//													title: 'test',
//													start: '2021-06-01',
//													end: '2021-06-02'
//												});
//											}
											successCallback(result);
										},
										isProcessMsg : false
									};
									
									com.sbm.executeDynamic(getScheduleOption, {
										"dma_search" : {
											"EMP_CD" : empCd
										}
									});
								},
								color: "skyblue",
								textColor: "white"
							},
							{
								googleCalendarId: "ko.south_korea#holiday@group.v.calendar.google.com",
								className: "koHolidays",
								color: "red",
								textColor: "white"
							}
						]
					});
					
					calendar.render();
				};
				
				
}}}]},{T:1,N:'script',A:{'ev:event':'onattributeChanged(type,value)',type:'text/javascript'},E:[{T:4,cdata:function(scopeObj,type,value){with(scopeObj){var udc_obj=WebSquare.util.getComponentById(WebSquare.scope_obj); 
}}}]},{T:1,N:'script',A:{'ev:event':'ondestroyed()',type:'text/javascript'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){var udc_obj=WebSquare.util.getComponentById(WebSquare.scope_obj); 
}}}]},{T:1,N:'div',A:{id:'_calDiv',style:'position: relative;width: 100%;'}}]}]}]}]})