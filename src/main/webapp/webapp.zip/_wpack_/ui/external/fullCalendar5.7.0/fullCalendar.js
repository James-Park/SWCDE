/*amd /ui/external/fullCalendar5.7.0/fullCalendar.xml 931 21d9ad334ef9c46447a5b1271f1be654588ca16cba3dd187b822b18522361aa4 */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',E:[{T:1,N:'w2:type',E:[{T:3,text:'DEFAULT'}]},{T:1,N:'w2:buildDate'},{T:1,N:'xf:model',E:[{T:1,N:'w2:dataCollection',A:{baseNode:'map'}},{T:1,N:'w2:workflowCollection'}]},{T:1,N:'script',A:{type:'text/javascript',lazy:'false'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){
        
	scwin.onpageload = function() {
		udc_fullCalendar.init();
	};
	
	scwin.onpageunload = function() {
		
	};
	
	
}}}]},{T:1,N:'w2:require',A:{src:'/ui/SP/externalJS/fullCalendar/udc/udc_fullCalendar.xml'}}]},{T:1,N:'body',A:{'ev:onpageload':'scwin.onpageload','ev:onpageunload':'scwin.onpageunload'},E:[{T:1,N:'w2:udc_fullCalendar',A:{style:'margin: 30px',id:'udc_fullCalendar'}}]}]}]})