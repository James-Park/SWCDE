/*amd /ui/external/xlsxJS/gridView_xlsxJS.xml 7723 63622f8e048fe60fa44f23b063a8374e645878edbc48d44151bf8edbd9d0cf49 */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',E:[{T:1,N:'w2:type',E:[{T:3,text:'DEFAULT'}]},{T:1,N:'w2:buildDate'},{T:1,N:'xf:model',E:[{T:1,N:'w2:dataCollection',A:{baseNode:'map'},E:[{T:1,N:'w2:dataMap',A:{baseNode:'map',id:'dma_searchParam'},E:[{T:1,N:'w2:keyInfo',E:[{T:1,N:'w2:key',A:{id:'name',name:'이름',dataType:'text'}},{T:1,N:'w2:key',A:{id:'tel',name:'전화번호',dataType:'text'}}]}]},{T:1,N:'w2:dataList',A:{baseNode:'list',repeatNode:'map',id:'dlt_userList',saveRemovedData:'true'},E:[{T:1,N:'w2:columnInfo',E:[{T:1,N:'w2:column',A:{id:'id',name:'아이디',dataType:'text'}},{T:1,N:'w2:column',A:{id:'name',name:'이름',dataType:'text'}},{T:1,N:'w2:column',A:{id:'tel',name:'전화번호',dataType:'text'}}]},{T:1,N:'w2:data',A:{use:'false'}}]}]},{T:1,N:'w2:workflowCollection'},{T:1,N:'xf:submission',A:{id:'submission1',ref:'data:json,{"id":"dma_searchParam","key":"param"}',target:'data:json,{"id":"dlt_userList","key":"data"}',action:'/test/testJsonMap.do',method:'post',mediatype:'application/json',encoding:'UTF-8',instance:'',replace:'',errorHandler:'',customHandler:'',mode:'asynchronous',processMsg:'','ev:submit':'','ev:submitdone':'','ev:submiterror':'',abortTrigger:''}}]},{T:1,N:'script',A:{src:'https://cdn.jsdelivr.net/npm/xlsx/dist/xlsx.full.min.js'}},{T:1,N:'script',A:{type:'text/javascript'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){scwin.onpageload = function () {
    scwin.bindFileChangeEvent(upd_upload1, dlt_userList);
};

scwin.trigger1_onclick = function (e) {
    $w.executeSubmission("submission1");
};

scwin.btn_excelDownload_onclick = function (e) {
    scwin.downloadExcel(dlt_userList.getAllJSON());
};

/**
 * @method
 * @name bindFileChangeEvent
 * @description 파일 선택 시 이벤트가 발생하도록 바인딩한다.
 * @param {object} uploadObj 업로드 컴포넌트 객체
 * @param {object} dataListObj DataList 객체
 * @hidden N
 * @exception 
 * @example ${example}
 */
scwin.bindFileChangeEvent = function (uploadObj, dataListObj) {
    var fileInputId = uploadObj.getID() + "_fakeinput";
    document.getElementById(fileInputId).addEventListener('change', function (event) {
        scwin.handleFile(event, { dataList: dataListObj });
    }, false);
};

/**
 * @method
 * @name handleFile
 * @description 파일 선택 시 데이터를 읽은 데이터를 옵션으로 전달한 DataList 객체에 저장한다.
 * @param {object} e 이벤트 객체
 * @param {object} option 옵션 정보
 * @hidden N
 * @exception 
 * @example ${example}
 */
scwin.handleFile = function (e, option) {
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = function (event) {
        debugger;
        const data = new Uint8Array(event.target.result);
        const workbook = XLSX.read(data, { type: 'array' });

        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const jsonData = XLSX.utils.sheet_to_row_object_array(worksheet);

        option.dataList.setJSON(jsonData);
    };

    reader.readAsArrayBuffer(file);
}

/**
 * @method JSON 데이터를 엑셀로 변환하고 다운로드하는 함수
 * @name downloadExcel
 * @description JSON 데이터를 엑셀 파일로 다운로드한다.
 * @param {string} jsonData 엑셀 파일로 다운로드 받을 JSON 데이터
 * @hidden N
 * @exception 
 * @example ${example}
 */
scwin.downloadExcel = function (jsonData) {
    // JSON 데이터를 워크시트로 변환
    const worksheet = XLSX.utils.json_to_sheet(jsonData);

    // 새로운 워크북 생성
    const workbook = XLSX.utils.book_new();

    // 워크북에 워크시트 추가
    XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");

    // 엑셀 파일 생성 및 다운로드
    XLSX.writeFile(workbook, "data.xlsx");
};



}}}]}]},{T:1,N:'body',A:{'ev:onpageload':'scwin.onpageload'},E:[{T:1,N:'xf:group',A:{style:'width:100.0%;height:37px;',id:'',class:''},E:[{T:1,N:'w2:textbox',A:{label:'엑셀 업로드/다운로드 using XLSX.js',style:'width:578px;height:44px;font-size:30px;font-weight:bold;float:left;',id:''}},{T:1,N:'xf:trigger',A:{'ev:onclick':'scwin.btn_excelDownload_onclick',style:'width:127px;height:27px;float:right;margin-top:5px;margin-right:5px;',id:'btn_excelDownload',type:'button'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'엑셀 다운로드'}]}]},{T:1,N:'xf:trigger',A:{'ev:onclick':'scwin.trigger1_onclick',id:'trigger1',style:'width: 80px;height: 27px;float:right;margin-top:5px;margin-right:5px;',type:'button'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'조회'}]}]},{T:1,N:'w2:upload',A:{imageStyle:'position:absolute;vertical-align:middle;word-wrap:break-word',inputStyle:'vertical-align:middle;word-wrap:break-word',style:'width: 250px;height: 23px;',id:'upd_upload1'}}]},{T:1,N:'xf:group',A:{tagname:'table',style:'width:100.00%;',id:'',class:'w2tb'},E:[{T:1,N:'w2:attributes',E:[{T:1,N:'w2:summary'}]},{T:1,N:'xf:group',A:{tagname:'caption'}},{T:1,N:'xf:group',A:{tagname:'colgroup'},E:[{T:1,N:'xf:group',A:{tagname:'col',style:'width:25.00%;'}},{T:1,N:'xf:group',A:{tagname:'col',style:'width:25.00%;'}},{T:1,N:'xf:group',A:{tagname:'col',style:'width:25.00%;'}},{T:1,N:'xf:group',A:{tagname:'col',style:'width:25.00%;'}}]},{T:1,N:'xf:group',A:{tagname:'tr',style:'height:32.00px;'},E:[{T:1,N:'xf:group',A:{tagname:'th',style:'',class:'w2tb_th'},E:[{T:3,text:'\n    				이름\n    				'},{T:1,N:'w2:attributes',E:[{T:1,N:'w2:scope',E:[{T:3,text:'row'}]}]}]},{T:1,N:'xf:group',A:{tagname:'td',style:'',class:'w2tb_td'},E:[{T:1,N:'xf:input',A:{adjustMaxLength:'false',id:'',style:'width: 144px;height: 21px;',ref:'data:dma_searchParam.name'}}]},{T:1,N:'xf:group',A:{tagname:'th',style:'',class:'w2tb_th'},E:[{T:3,text:'\n    				전화번호\n    				'},{T:1,N:'w2:attributes',E:[{T:1,N:'w2:scope',E:[{T:3,text:'row'}]}]}]},{T:1,N:'xf:group',A:{tagname:'td',style:'',class:'w2tb_td'},E:[{T:1,N:'xf:input',A:{adjustMaxLength:'false',id:'',style:'width: 144px;height: 21px;',ref:'data:dma_searchParam.tel'}}]}]}]},{T:1,N:'w2:gridView',A:{id:'',ignoreToggleOnDisabled:'false',useShiftKey:'true',style:'width:100.0%;height:314px;margin-top:10px',useFilterList:'false',scrollByColumn:'false',defaultCellHeight:'20',showSortableUseFilter:'false',scrollByColumnAdaptive:'false',summaryAuto:'false',summaryOnlyAuto:'false',applyAllColumnStyle:'false',dataList:'data:dlt_userList',ignoreCellClick:'false',autoFit:'allColumn',tooltipDisplay:'true'},E:[{T:1,N:'w2:caption',A:{style:'',id:'caption2',value:'this is a grid caption.'}},{T:1,N:'w2:header',A:{style:'',id:'header2'},E:[{T:1,N:'w2:row',A:{style:'',id:'row3'},E:[{T:1,N:'w2:column',A:{width:'70',inputType:'text',style:'',id:'column7',value:'아이디',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'70',inputType:'text',style:'',id:'column5',value:'이름',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'70',inputType:'text',style:'',id:'column3',value:'전화번호',blockSelect:'false',displayMode:'label'}}]}]},{T:1,N:'w2:gBody',A:{style:'',id:'gBody2'},E:[{T:1,N:'w2:row',A:{style:'',id:'row4'},E:[{T:1,N:'w2:column',A:{width:'70',inputType:'text',style:'',id:'id',value:'',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'70',inputType:'text',style:'',id:'name',value:'',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'70',inputType:'text',style:'',id:'tel',value:'',blockSelect:'false',displayMode:'label'}}]}]}]}]}]}]})