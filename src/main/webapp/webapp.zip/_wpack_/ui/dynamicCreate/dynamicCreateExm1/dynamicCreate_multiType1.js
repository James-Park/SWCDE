/*amd /ui/dynamicCreate/dynamicCreateExm1/dynamicCreate_multiType1.xml 8812 0b1028527988a531cd49a4a45b86455ce83e5f2b16af78ccfc284190f9024fbb */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',A:{},E:[{T:1,N:'w2:type',E:[{T:3,text:'DEFAULT'}]},{T:1,N:'w2:buildDate'},{T:1,N:'xf:model',E:[{T:1,N:'w2:dataCollection',A:{baseNode:'map'},E:[{T:1,N:'w2:dataList',A:{baseNode:'list',repeatNode:'map',id:'dlt_layoutMeta',saveRemovedData:'true'},E:[{T:1,N:'w2:columnInfo',E:[{T:1,N:'w2:column',A:{id:'inputType',name:'inputType',dataType:'text'}},{T:1,N:'w2:column',A:{id:'labelName',name:'labelName',dataType:'text'}},{T:1,N:'w2:column',A:{id:'value',name:'value',dataType:'text'}}]},{T:1,N:'w2:data',A:{use:'true'},E:[{T:1,N:'w2:row',E:[{T:1,N:'inputType',E:[{T:4,cdata:'input'}]},{T:1,N:'labelName',E:[{T:4,cdata:'이름'}]},{T:1,N:'value',E:[{T:4,cdata:'홍길동'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'inputType',E:[{T:4,cdata:'select'}]},{T:1,N:'labelName',E:[{T:4,cdata:'부서1'}]},{T:1,N:'value',E:[{T:4,cdata:'A03'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'inputType',E:[{T:4,cdata:'inputCalendar'}]},{T:1,N:'labelName',E:[{T:4,cdata:'시작일자'}]},{T:1,N:'value',E:[{T:4,cdata:'20180101'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'inputType',E:[{T:4,cdata:'inputCalendar'}]},{T:1,N:'labelName',E:[{T:4,cdata:'종료일자'}]},{T:1,N:'value',E:[{T:4,cdata:'20181231'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'inputType',E:[{T:4,cdata:'inputButton'}]},{T:1,N:'labelName',E:[{T:4,cdata:'코드타입1'}]},{T:1,N:'value',E:[{T:4,cdata:'02'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'inputType',E:[{T:4,cdata:'select'}]},{T:1,N:'labelName',E:[{T:4,cdata:'부서2'}]},{T:1,N:'value',E:[{T:4,cdata:'A02'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'inputType',E:[{T:4,cdata:'radio'}]},{T:1,N:'labelName',E:[{T:4,cdata:'코드타입2'}]},{T:1,N:'value',E:[{T:4,cdata:'01'}]}]}]}]},{T:1,N:'w2:dataList',A:{baseNode:'list',repeatNode:'map',id:'dlt_codeType1',saveRemovedData:'true'},E:[{T:1,N:'w2:columnInfo',E:[{T:1,N:'w2:column',A:{id:'code',name:'code',dataType:'text'}},{T:1,N:'w2:column',A:{id:'label',name:'label',dataType:'text'}}]},{T:1,N:'w2:data',A:{use:'true'},E:[{T:1,N:'w2:row',E:[{T:1,N:'code',E:[{T:4,cdata:'A01'}]},{T:1,N:'label',E:[{T:4,cdata:'인사과'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'code',E:[{T:4,cdata:'A02'}]},{T:1,N:'label',E:[{T:4,cdata:'총무과'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'code',E:[{T:4,cdata:'A03'}]},{T:1,N:'label',E:[{T:4,cdata:'홍보과'}]}]}]}]}]},{T:1,N:'w2:workflowCollection'}]},{T:1,N:'script',A:{type:'text/javascript',lazy:'false'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){
	
	scwin.onpageload = function() {
		scwin.createLayout();
	};

	scwin.onpageunload = function() {
	};

	/** 
	 * 컴포넌트 동적 생성을 위한 DataList(dlt_layoutMeta)에 저장된 Layout 메타 데이터를 이용해서 화면을 동적으로 생성한다.
	 */ 
	scwin.createLayout = function() {
		var layoutCount = dlt_layoutMeta.getRowCount();

		for (var idx = 0; idx < layoutCount; idx++) {
			gen_Layout.insertChild(idx);

			var grpObj = gen_Layout.getChild(idx, "grp_layout");
			var layoutType = dlt_layoutMeta.getCellData(idx, "inputType");
			var labelName = dlt_layoutMeta.getCellData(idx, "labelName");
			var value = dlt_layoutMeta.getCellData(idx, "value");

			// Label 이름을 세팅한다.
			var labelObj = gen_Layout.getChild(idx, "tbx_label");
			labelObj.setValue(labelName);

			// 각 Label의 InputType 별로 컴포넌트를 동적으로 세팅한다.
			if (layoutType == "input") {
				scwin.createInput(idx, grpObj, value);
			} else if (layoutType == "select") {
				scwin.createSelect(idx, grpObj, value);
			} else if (layoutType == "radio") {
				scwin.createRadio(idx, grpObj, value);
			} else if (layoutType == "inputCalendar") {
				scwin.createInputCalendar(idx, grpObj, value);
			} else if (layoutType == "inputButton") {
				scwin.createInputButton(idx, grpObj, value);
			}
		}
	};

	/**
	 * Input 컴포넌트 동적으로 생성하고 값을 세팅한다.
	 *
	 * @param {Number} idx 컴포넌트 순번
	 * @param {Object} grpObj Input 컴포넌트의 부모 Group 객체
	 * @param {String} value Input에 세팅할 문자열 값
	 */
	scwin.createInput = function(idx, grpObj, value) {
		$p.dynamicCreate("ibx_data" + idx, "input", {
			style : "width:120px; height:21px; float:left; margin : 5px;",
		}, grpObj);

		var comObj = $p.getComponentById("ibx_data" + idx);
		comObj.setValue(value);
	};

	/**
	 * SelectBox 컴포넌트 동적으로 생성하고 값을 세팅한다.
	 *
	 * @param {Number} idx 컴포넌트 순번
	 * @param {Object} grpObj SelectBox 컴포넌트의 부모 Group 객체
	 * @param {String} value Input에 세팅할 문자열 값
	 */
	scwin.createSelect = function(idx, grpObj, value) {
		$p.dynamicCreate("sbx_data" + idx, "selectbox", {
			style : "width:170px; height:21px; float:left; margin : 5px;"
		}, grpObj);

		var comObj = $p.getComponentById("sbx_data" + idx);
		comObj.setNodeSet("data:dlt_codeType1", "label", "code");
		comObj.setValue(value);
	};

	/**
	 * Radio 컴포넌트 동적으로 생성하고 값을 세팅한다.
	 *
	 * @param {Number} idx 컴포넌트 순번
	 * @param {Object} grpObj SelectBox 컴포넌트의 부모 Group 객체
	 * @param {String} value Input에 세팅할 문자열 값
	 */
	scwin.createRadio = function(idx, grpObj, value) {
		$p.dynamicCreate("rad_data" + idx, "radio", {
			style : "width:200px; height:21px; float:left; margin : 5px;",
			cols : "3"
		}, grpObj);

		var comObj = $p.getComponentById("rad_data" + idx);
		comObj.setNodeSet("data:dlt_codeType1", "label", "code");
		comObj.setValue(value);
	};

	/**
	 * InputCalendar 컴포넌트 동적으로 생성하고 값을 세팅한다.
	 *
	 * @param {Number} idx 컴포넌트 순번
	 * @param {Object} grpObj InputCalendar 컴포넌트의 부모 Group 객체
	 * @param {String} value Input에 세팅할 문자열 값
	 */
	scwin.createInputCalendar = function(idx, grpObj, value) {
		$p.dynamicCreate("cal_data" + idx, "inputCalendar", {
			style : "width:100px; height:21px; float:left; margin : 5px;"
		}, grpObj);

		var comObj = $p.getComponentById("cal_data" + idx);
		comObj.setValue(value);
	};

	/**
	 * Input + Trigger(Button) 컴포넌트를 동적으로 생성하고 값을 세팅한다.
	 *
	 * @param {Number} idx 컴포넌트 순번
	 * @param {Object} grpObj Input + Trigger(Button) 컴포넌트의 부모 Group 객체
	 * @param {String} value Input에 세팅할 문자열 값
	 */
	scwin.createInputButton = function(idx, grpObj, value) {
		$p.dynamicCreate("ibx_data" + idx, "input", {
			style : "width:120px; height:21px; float:left; margin : 5px;",
			disabled : true
		}, grpObj);

		var inputObj = $p.getComponentById("ibx_data" + idx);
		inputObj.setValue(value);

		$p.dynamicCreate("btn_search" + idx, "trigger", {
			style : "width:40px; height:21px; float:left; margin : 5px;", 
			value : "검색"
		}, grpObj);

		var btnObj = $p.getComponentById("btn_search" + idx);
		btnObj.bind("onclick", scwin.openCodeSearchPopup);
		btnObj.setUserData("valueComId", "ibx_data" + idx);
	};

	/**
	 * 코드 검색 팝업 창을 오픈한다.
	 */
	scwin.openCodeSearchPopup = function() {
		requires("uiplugin.popup");

		var rowJSON = {
			comId : this.getUserData("valueComId"),
			callbackFunc : $p.id + "scwin.setCode"
		};

		var dataObj = {
			type : "json", // 데이터 타입. "xml","string","json","array" 
			data : rowJSON, // 전달 데이터 객체. 
			name : "param" // 변수명. popup에서 $w.getParameter( "param" )로 깨내올 수 있다. 
		};

		var options = {
			id : "popup1",
			type : "wframePopup",
			width : "500px",
			height : "264px",
			top : "130px",
			left : "200px",
			popupName : "openPopup1",
			modal : true,
			dataObject : dataObj
		};

		$p.openPopup("popup_search.xml", options);
	};
	
	/**
	 * 컴포넌트 동적 생성을 위한 메타 데이터(dlt_layoutMeta)를 이용해서 화면을 동적으로 생성한다.
	 * 
	 * @param {String} comId 컴포넌트 
	 * @return {String} value 
	 */
	scwin.setCode = function(comId, value) {
		var comObj = $p.getComponentById(comId);
		if ((comObj !== null) && (typeof value !== "undefined")) {
			comObj.setValue(value);
		}
		return true;
	};

}}}]}]},{T:1,N:'body',A:{'ev:onpageload':'scwin.onpageload','ev:onpageunload':'scwin.onpageunload'},E:[{T:1,N:'xf:group',A:{style:'padding:10px;',id:''},E:[{T:1,N:'w2:generator',A:{tagname:'div',style:'',id:'gen_Layout'},E:[{T:1,N:'xf:group',A:{style:'width:400px;height:33px;border-style: solid;padding: 1px;border-width:1px;float:left',id:'grp_layout',class:''},E:[{T:1,N:'w2:textbox',A:{style:'width:120px;padding:10px;font-weight:bold;background-color:#F0F0F0;float:left;',label:'Label',id:'tbx_label'}}]}]}]}]}]}]})