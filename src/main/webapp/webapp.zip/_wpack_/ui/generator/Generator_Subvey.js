/*amd /ui/generator/Generator_Subvey.xml 10481 d6e0e222627876b9ad71180752142f19e2bd33880069015ab91a3990590622f9 */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',E:[{T:1,N:'w2:buildDate'},{T:1,N:'xf:model',E:[{T:1,N:'w2:dataCollection',E:[{T:1,N:'w2:dataList',A:{id:'dlt_Survey',baseNode:'list',style:'',repeatNode:'map'},E:[{T:1,N:'w2:columnInfo',E:[{T:1,N:'w2:column',A:{id:'chk_1',name:'chk_1',dataType:'text'}},{T:1,N:'w2:column',A:{id:'chk_2',name:'chk_2',dataType:'text'}},{T:1,N:'w2:column',A:{id:'itm_cd_1',name:'itm_cd_1',dataType:'text'}},{T:1,N:'w2:column',A:{id:'itm_cd_2',name:'itm_cd_2',dataType:'text'}},{T:1,N:'w2:column',A:{id:'itm_nm_1',name:'itm_nm_1',dataType:'text'}},{T:1,N:'w2:column',A:{id:'itm_nm_2',name:'itm_nm_2',dataType:'text'}},{T:1,N:'w2:column',A:{id:'itm_desc_1',name:'itm_desc_1',dataType:'text'}},{T:1,N:'w2:column',A:{id:'itm_desc_2',name:'itm_desc_2',dataType:'text'}}]}]}]}]},{T:1,N:'script',A:{type:'javascript',lazy:'false'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){ 
		
			scwin.onpageload = function() {
				scwin.setData();
			};
			
			scwin.setData = function() {
				var resBody = 
				  {
				  "message": {
					"description": "13건이 조회되었습니다.",
					"code": "info",
					"stacktrace": null,
					"type": "info",
					"msg": "13건이 조회되었습니다."
				  },
				  "svrtime": 1404733808051,
				  "data": {
					"itmList": [
					  {
						"itm_cd_2": "IC00000002",
						"itm_nm_1": "이름",
						"itm_nm_2": "성별",
						"itm_cd_1": "IC00000001",
						"chk_2": "Y",
						"itm_desc_1": null,
						"itm_desc_2": null,
						"chk_1": "Y"
					  },
					  {
						"itm_cd_2": "IC00000004",
						"itm_nm_1": "생년월일",
						"itm_nm_2": "E-mail",
						"itm_cd_1": "IC00000003",
						"chk_2": "Y",
						"itm_desc_1": null,
						"itm_desc_2": null,
						"chk_1": "Y"
					  },
					  {
						"itm_cd_2": "IC00000009",
						"itm_nm_1": "주소",
						"itm_nm_2": "전화번호(집)",
						"itm_cd_1": "IC00000005",
						"chk_2": "Y",
						"itm_desc_1": null,
						"itm_desc_2": null,
						"chk_1": "Y"
					  },
					  {
						"itm_cd_2": "IC00000011",
						"itm_nm_1": "휴대폰번호",
						"itm_nm_2": "직업",
						"itm_cd_1": "IC00000010",
						"chk_2": "Y",
						"itm_desc_1": null,
						"itm_desc_2": null,
						"chk_1": "Y"
					  },
					  {
						"itm_cd_2": "IC00000015",
						"itm_nm_1": "키/몸무게",
						"itm_nm_2": "흡연여부",
						"itm_cd_1": "IC00000012",
						"chk_2": "Y",
						"itm_desc_1": null,
						"itm_desc_2": null,
						"chk_1": "Y"
					  },
					  {
						"itm_cd_2": "IC00000030",
						"itm_nm_1": "음주여부",
						"itm_nm_2": "헌혈",
						"itm_cd_1": "IC00000022",
						"chk_2": "N",
						"itm_desc_1": null,
						"itm_desc_2": "* 최근 2개월 내",
						"chk_1": "Y"
					  },
					  {
						"itm_cd_2": "IC00000040",
						"itm_nm_1": "임상시험 참여 경험",
						"itm_nm_2": "현재 복용중인 약",
						"itm_cd_1": "IC00000035",
						"chk_2": "N",
						"itm_desc_1": "* 최근 3개월 내",
						"itm_desc_2": "* 예) 혈압약, 고지혈증약, 당뇨약, 위산억제제 건강보조식품, 한약, 비타민제, 홍삼제품, 소화제, 감기약, 인공눈물, 안약, 연고, 파스 등",
						"chk_1": "N"
					  },
					  {
						"itm_cd_2": "IC00000046",
						"itm_nm_1": "30일 이내 약물복용",
						"itm_nm_2": "알레르기 / 과민반응",
						"itm_cd_1": "IC00000043",
						"chk_2": "N",
						"itm_desc_1": null,
						"itm_desc_2": "* 예) 천식, 아토피피부염, 비염, 음식물 알레르기, 항생제/아스피린 과민반응 등",
						"chk_1": "N"
					  },
					  {
						"itm_cd_2": "IC00000050",
						"itm_nm_1": "병력 / 수술력",
						"itm_nm_2": "기호음식",
						"itm_cd_1": "IC00000047",
						"chk_2": "N",
						"itm_desc_1": "* 예) 수술 또는 입원치료, , B형/C형 간염 보균자",
						"itm_desc_2": null,
						"chk_1": "N"
					  },
					  {
						"itm_cd_2": "IC00000059",
						"itm_nm_1": "비정상적인 식이",
						"itm_nm_2": "혈액채취 가능 여부",
						"itm_cd_1": "IC00000056",
						"chk_2": "N",
						"itm_desc_1": "* 예) 자몽, 자몽쥬스, 자몽 성분이 포함된 이온음료 등의 정기적인 섭취, 단백질 위주의 식사, 채식주의, 불규칙적인 식사 등",
						"itm_desc_2": "* 추적관찰을 위한 방문과 연구기간 동안 혈액채취 가능 여부",
						"chk_1": "N"
					  },
					  {
						"itm_cd_2": "IC00000061",
						"itm_nm_1": "주의사항 준수여부",
						"itm_nm_2": "운동 여부",
						"itm_cd_1": "IC00000060",
						"chk_2": "N",
						"itm_desc_1": "* 주의사항 : 스크리닝 방문일부터 최종 방문까지 카페인, 음주, 흡연, 과도한 신체활동 금지, 동의서 작성 이후 최종방문까지 의약품 복용, 헌혈 금지, 비정상적인 식사 금지",
						"itm_desc_2": null,
						"chk_1": "N"
					  },
					  {
						"itm_cd_2": "IC00000067",
						"itm_nm_1": "지원 경로",
						"itm_nm_2": "피임 가능 여부",
						"itm_cd_1": "IC00000064",
						"chk_2": "N",
						"itm_desc_1": null,
						"itm_desc_2": "* 임상시험용의약품 첫 투여일로부터 마지막 임상시험용의약품 투여일 이후 60일  까지 의학적으로 인정되는 적절한 이중피임법을 사용하고 정자를 제공하지 않는 것에 동의합니까?",
						"chk_1": "N"
					  },
					  {
						"itm_cd_2": null,
						"itm_nm_1": "기타",
						"itm_nm_2": null,
						"itm_cd_1": "IC00000070",
						"chk_2": null,
						"itm_desc_1": null,
						"itm_desc_2": null,
						"chk_1": "N"
					  }
					]
				  }
				};
				
				var dataLength = resBody.data.itmList.length;
				for(var i = 0; i < dataLength; i++) {
					 gen_ItmList.insert();
					 gen_ItmList.getChild( i , "chk_1" ).setValue(resBody.data.itmList[i].chk_1);
					 gen_ItmList.getChild( i , "itm_cd_1" ).setValue(resBody.data.itmList[i].itm_cd_1);
					 gen_ItmList.getChild( i , "itm_nm_1" ).setValue(resBody.data.itmList[i].itm_nm_1);
					 gen_ItmList.getChild( i , "itm_desc_1" ).setValue(resBody.data.itmList[i].itm_desc_1);
					 gen_ItmList.getChild( i , "chk_2" ).setValue(resBody.data.itmList[i].chk_2);
					 gen_ItmList.getChild( i , "itm_cd_2" ).setValue(resBody.data.itmList[i].itm_cd_2);
					 gen_ItmList.getChild( i , "itm_nm_2" ).setValue(resBody.data.itmList[i].itm_nm_2);
					 gen_ItmList.getChild( i , "itm_desc_2" ).setValue(resBody.data.itmList[i].itm_desc_2);
				}
			};
			
			scwin.getData = function() {
				var dataLength = gen_ItmList.getLength();
				for(var i = 0; i < dataLength; i++) {
					 dlt_Survey.insertRow();
					 dlt_Survey.setCellData(i, "chk_1", gen_ItmList.getChild( i , "chk_1" ).getValue());
					 dlt_Survey.setCellData(i, "itm_cd_1", gen_ItmList.getChild( i , "itm_cd_1" ).getValue());
					 dlt_Survey.setCellData(i, "itm_nm_1", gen_ItmList.getChild( i , "itm_nm_1" ).getValue());
					 dlt_Survey.setCellData(i, "itm_desc_1", gen_ItmList.getChild( i , "itm_desc_1" ).getValue());
					 dlt_Survey.setCellData(i, "chk_2", gen_ItmList.getChild( i , "chk_2" ).getValue());
					 dlt_Survey.setCellData(i, "itm_cd_2", gen_ItmList.getChild( i , "itm_cd_2" ).getValue());
					 dlt_Survey.setCellData(i, "itm_nm_2", gen_ItmList.getChild( i , "itm_nm_2" ).getValue());
					 dlt_Survey.setCellData(i, "itm_desc_2", gen_ItmList.getChild( i , "itm_desc_2" ).getValue());
				}
				
				alert(JSON.stringify(dlt_Survey.getAllJSON()));
			};
		
}}}]}]},{T:1,N:'body',A:{'ev:onpageload':'scwin.onpageload'},E:[{T:1,N:'xf:group',A:{id:'group1',style:'position: relative;width: 100%;height: 40px;',class:''},E:[{T:1,N:'xf:trigger',A:{type:'button',id:'trigger1',style:'position: relative;width:185px;height:31px;'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'변경된 값을 DataList에 저장'}]},{T:1,N:'script',A:{'ev:event':'onclick',type:'javascript'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){ 
					scwin.getData();
				
}}}]}]}]},{T:1,N:'table',A:{summary:'',id:'table1',style:'position: relative;width:100.00%;height: 0;',class:'w2tb'},E:[{T:1,N:'xf:group',A:{tagname:'colgroup'},E:[{T:1,N:'xf:group',A:{style:'width:3.95%;',tagname:'col'}},{T:1,N:'xf:group',A:{style:'width:6.83%;',tagname:'col'}},{T:1,N:'xf:group',A:{style:'width:11.67%;',tagname:'col'}},{T:1,N:'xf:group',A:{style:'width:27.55%;',tagname:'col'}},{T:1,N:'xf:group',A:{style:'width:3.45%;',tagname:'col'}},{T:1,N:'xf:group',A:{style:'width:8.14%;',tagname:'col'}},{T:1,N:'xf:group',A:{style:'width:11.99%;',tagname:'col'}},{T:1,N:'xf:group',A:{style:'width:26.40%;',tagname:'col'}}]},{T:1,N:'w2:generator',A:{id:'gen_ItmList',style:'',tagname:'tbody'},E:[{T:1,N:'xf:group',A:{tagname:'tr'},E:[{T:1,N:'xf:group',A:{style:'',class:'w2tb_th',tagname:'th'},E:[{T:1,N:'xf:select',A:{appearance:'full',id:'chk_1',style:'position: relative;width:22px;height:21px;',selectedindex:'-1',cols:'',rows:''},E:[{T:1,N:'xf:choices',E:[{T:1,N:'xf:item',E:[{T:1,N:'xf:label'},{T:1,N:'xf:value',E:[{T:4,cdata:'Y'}]}]}]}]}]},{T:1,N:'xf:group',A:{style:'',class:'w2tb_td',tagname:'td'},E:[{T:1,N:'w2:textbox',A:{id:'itm_cd_1',style:'position: relative;width:100%;height: 23px;',label:''}}]},{T:1,N:'xf:group',A:{style:'',class:'w2tb_td',tagname:'td'},E:[{T:1,N:'w2:textbox',A:{id:'itm_nm_1',style:'position: relative;width:100%;height: 23px;',label:''}}]},{T:1,N:'xf:group',A:{style:'',class:'w2tb_td',tagname:'td'},E:[{T:1,N:'xf:input',A:{id:'itm_desc_1',style:'position: relative;width:319px;height:21px;'}}]},{T:1,N:'xf:group',A:{style:'',class:'w2tb_th',tagname:'th'},E:[{T:1,N:'xf:select',A:{appearance:'full',cols:'',id:'chk_2',rows:'',selectedindex:'-1',style:'position: relative;width:22px;height:21px;'},E:[{T:1,N:'xf:choices',E:[{T:1,N:'xf:item',E:[{T:1,N:'xf:label'},{T:1,N:'xf:value',E:[{T:4,cdata:'Y'}]}]}]}]}]},{T:1,N:'xf:group',A:{style:'',class:'w2tb_td',tagname:'td'},E:[{T:1,N:'w2:textbox',A:{id:'itm_cd_2',style:'position: relative;width:100%;height: 23px;',label:''}}]},{T:1,N:'xf:group',A:{style:'',class:'w2tb_td',tagname:'td'},E:[{T:1,N:'w2:textbox',A:{id:'itm_nm_2',style:'position: relative;width:100%;height: 23px;',label:''}}]},{T:1,N:'xf:group',A:{style:'',class:'w2tb_td',tagname:'td'},E:[{T:1,N:'xf:input',A:{id:'itm_desc_2',style:'position: relative;width:309px;height:21px;'}}]}]}]}]}]}]}]})