/*amd /ui/submission/submitEventControl_미완성/submission_submitDone.xml 8637 9569ebc3e347a29b2805b49f473e354806aed58d327de43072b2ee75633b0ce8 */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',E:[{T:1,N:'w2:type',E:[{T:3,text:'DEFAULT'}]},{T:1,N:'w2:buildDate'},{T:1,N:'xf:model',E:[{T:1,N:'w2:dataCollection',A:{baseNode:'map'},E:[{T:1,N:'w2:dataMap',A:{baseNode:'map',id:'dma_dataMap1'},E:[{T:1,N:'w2:keyInfo',E:[{T:1,N:'w2:key',A:{id:'procId',name:'procId',dataType:'text'}},{T:1,N:'w2:key',A:{id:'subId',name:'subId',dataType:'text'}},{T:1,N:'w2:key',A:{id:'name',name:'name',dataType:'text'}},{T:1,N:'w2:key',A:{id:'tel',name:'tel',dataType:'text'}}]},{T:1,N:'w2:data',A:{use:'true'},E:[{T:1,N:'procId',E:[{T:4,cdata:'PR001'}]},{T:1,N:'subId',E:[{T:4,cdata:'SB002'}]},{T:1,N:'name',E:[{T:4,cdata:'Peter'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2223-4421'}]}]}]},{T:1,N:'w2:dataList',A:{baseNode:'list',repeatNode:'map',id:'dlt_dataList1',saveRemovedData:'true'},E:[{T:1,N:'w2:columnInfo',E:[{T:1,N:'w2:column',A:{id:'id',name:'id',dataType:'text'}},{T:1,N:'w2:column',A:{id:'name',name:'name',dataType:'text'}},{T:1,N:'w2:column',A:{id:'tel',name:'tel',dataType:'text'}}]}]},{T:1,N:'w2:dataMap',A:{baseNode:'map',id:'dma_dataMap11'},E:[{T:1,N:'w2:keyInfo',E:[{T:1,N:'w2:key',A:{id:'id',name:'name1',dataType:'text'}},{T:1,N:'w2:key',A:{id:'name',name:'name2',dataType:'text'}},{T:1,N:'w2:key',A:{id:'tel',name:'name3',dataType:'text'}}]}]}]},{T:1,N:'w2:workflowCollection'},{T:1,N:'xf:submission',A:{id:'sbm_submission1',ref:'data:json,dma_dataMap1',target:'data:json,{"id":"dlt_dataList1","key":"data"}',action:'/restful/testJsonMap2',method:'get',mediatype:'application/json',encoding:'UTF-8',instance:'',replace:'',errorHandler:'',customHandler:'',mode:'asynchronous',processMsg:'','ev:submit':'','ev:submitdone':'scwin.sbm_submission1_submitdone','ev:submiterror':'',abortTrigger:''}},{T:1,N:'xf:submission',A:{id:'sbm_submission2',ref:'',target:'data:json,{"id":"dlt_dataList1","key":"data"}',action:'/restful/testJsonMap2',method:'get',mediatype:'application/json',encoding:'UTF-8',instance:'',replace:'',errorHandler:'',customHandler:'',mode:'asynchronous',processMsg:'','ev:submit':'','ev:submitdone':'','ev:submiterror':'',abortTrigger:''}},{T:1,N:'xf:submission',A:{abortTrigger:'',action:'/restful/testJsonMap3/{procId}/{subId}',customHandler:'',encoding:'UTF-8',errorHandler:'','ev:submit':'','ev:submitdone':'','ev:submiterror':'',id:'sbm_submission3',instance:'',mediatype:'application/json',method:'get',mode:'asynchronous',processMsg:'',ref:'data:json,dma_dataMap1',replace:'',target:'data:json,{"id":"dlt_dataList1","key":"data"}',style:''}}]},{T:1,N:'script',A:{type:'text/javascript',lazy:'false'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){
/**
 * http://127.0.0.1:8080/websquare/websquare.html?w2Config=/ui/submission/restful/config.xml&w2xPath=/ui/submission/restful/submission_methtod_get.xml
 */
scwin.onpageload = function () {

};

scwin.onpageunload = function () {

};

/**
 * Submission ref 정의된 DataMap의 데이터를 QueryString 방식으로 URL에 추가해서 전달하는 예제
 *
 * sbm_submission1.ref = "data:json,dma_dataMap1"
 * sbm_submission1.action = "/restful/testJsonMap2"
 */
scwin.btn_search1_onclick = function (e) {
	com.execute(sbm_submission1);
};


/**
 * JSON 객체를 QueryString 방식으로 URL에 추가해서 전달하는 예제
 *
 * sbm_submission2.action = "/restful/testJsonMap2"
 */
scwin.btn_search2_onclick = function (e) {
	var param = {
		procId: "PR001",
		subId: "SB002",
		name: "Peter",
		tel: "010-2223-4421"
	};
	com.execute(sbm_submission2, param);
};

/**
 * ref 정의된 DataMap의 데이터를 Path Variable과 QueryString 방식을 조합해서 URL에 추가해서 전달하는 예제
 *
 * DataMap 내에 정의된 Column Id 중에서 Path Variable로 정의되지 않은 컬럼(name, tel)을 QueryString 방식으로 추가된다.
 *
 * sbm_submission3.ref = "data:json,dma_dataMap1"
 * sbm_submission3.action = "/restful/testJsonMap3/{procId}/{subId}"
 */
scwin.btn_search3_onclick = function (e) {
	com.execute(sbm_submission3);
};

scwin.sbm_submission1_submitdone = function (e) {
	console.log("[sbm_submission1_submitdone]");
	console.log(e);
};

}}}]}]},{T:1,N:'body',A:{'ev:onpageload':'scwin.onpageload','ev:onpageunload':'scwin.onpageunload'},E:[{T:1,N:'xf:group',A:{id:'',style:'padding:10px'},E:[{T:1,N:'xf:group',A:{style:'width: 100%;height: 45px;',id:''},E:[{T:1,N:'w2:textbox',A:{style:'width:50%;height:23px;padding:10px;font-size:18px;font-weight:bold;float:left;',id:'',label:'GET 방식으로 파라미터 전달하기'}},{T:1,N:'xf:trigger',A:{style:'width:100px;height:23px;float:right;margin-top:10px;margin-right:10px;',id:'btn_search3',type:'button',nextTabID:'','ev:onclick':'scwin.btn_search3_onclick'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'조회 - 3'}]}]},{T:1,N:'xf:trigger',A:{id:'btn_search2',nextTabID:'',style:'width:108px;height:23px;float:right;margin-top:10px;margin-right:10px;',type:'button','ev:onclick':'scwin.btn_search2_onclick'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'조회 - 2'}]}]},{T:1,N:'xf:trigger',A:{id:'btn_search1',nextTabID:'',style:'width:108px;height:23px;float:right;margin-top:10px;margin-right:10px;',type:'button','ev:onclick':'scwin.btn_search1_onclick'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'조회 - 1'}]}]}]},{T:1,N:'xf:group',A:{style:'width:100%;',id:'grp_group1'},E:[{T:1,N:'xf:group',A:{tagname:'table',style:'width:100%;',id:'',class:'w2tb'},E:[{T:1,N:'w2:attributes',E:[{T:1,N:'w2:summary'}]},{T:1,N:'xf:group',A:{tagname:'caption'}},{T:1,N:'xf:group',A:{tagname:'colgroup'},E:[{T:1,N:'xf:group',A:{tagname:'col',style:'width:25.00%;'}},{T:1,N:'xf:group',A:{tagname:'col',style:'width:25.00%'}},{T:1,N:'xf:group',A:{tagname:'col',style:'width:25.00%;'}},{T:1,N:'xf:group',A:{tagname:'col',style:'width:25.00%'}}]},{T:1,N:'xf:group',A:{tagname:'tr',style:''},E:[{T:1,N:'xf:group',A:{tagname:'th',style:'',class:'w2tb_th'},E:[{T:3,text:'\n							procId\n							'},{T:1,N:'w2:attributes',E:[{T:1,N:'w2:scope',E:[{T:3,text:'row'}]}]}]},{T:1,N:'xf:group',A:{tagname:'td',style:'',class:'w2tb_td'},E:[{T:1,N:'xf:input',A:{adjustMaxLength:'false',id:'',style:'width: 144px;height: 21px;',ref:'data:dma_dataMap1.procId'}}]},{T:1,N:'xf:group',A:{tagname:'th',style:'',class:'w2tb_th'},E:[{T:3,text:'\n							subId\n							'},{T:1,N:'w2:attributes',E:[{T:1,N:'w2:scope',E:[{T:3,text:'row'}]}]}]},{T:1,N:'xf:group',A:{tagname:'td',style:'',class:'w2tb_td'},E:[{T:1,N:'xf:input',A:{adjustMaxLength:'false',id:'',style:'width: 144px;height: 21px;',ref:'data:dma_dataMap1.subId',refSync:''}}]}]},{T:1,N:'xf:group',A:{tagname:'tr',style:''},E:[{T:1,N:'xf:group',A:{tagname:'th',style:'',class:'w2tb_th'},E:[{T:3,text:'\n							seq\n							'},{T:1,N:'w2:attributes',E:[{T:1,N:'w2:scope',E:[{T:3,text:'row'}]}]}]},{T:1,N:'xf:group',A:{tagname:'td',style:'',class:'w2tb_td'},E:[{T:1,N:'xf:input',A:{adjustMaxLength:'false',id:'',style:'width: 144px;height: 21px;',ref:'data:dma_dataMap1.seq',refSync:''}}]},{T:1,N:'xf:group',A:{tagname:'th',style:'',class:'w2tb_th'},E:[{T:3,text:'\n							name\n							'},{T:1,N:'w2:attributes',E:[{T:1,N:'w2:scope',E:[{T:3,text:'row'}]}]}]},{T:1,N:'xf:group',A:{tagname:'td',style:'',class:'w2tb_td'},E:[{T:1,N:'xf:input',A:{adjustMaxLength:'false',id:'',style:'width: 144px;height: 21px;',ref:'data:dma_dataMap1.name'}}]}]}]}]},{T:1,N:'w2:gridView',A:{dataList:'data:dlt_dataList1',defaultCellHeight:'20',id:'',scrollByColumn:'false',scrollByColumnAdaptive:'false',style:'width:100%;height:150px;margin-top:10px;',autoFit:'allColumn'},E:[{T:1,N:'w2:caption',A:{style:'',id:'caption1',value:'this is a grid caption.'}},{T:1,N:'w2:header',A:{style:'',id:'header1'},E:[{T:1,N:'w2:row',A:{style:'',id:'row1'},E:[{T:1,N:'w2:column',A:{width:'70',inputType:'text',style:'height:20px',id:'column3',value:'id',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'70',inputType:'text',style:'height:20px',id:'column2',value:'name',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'70',inputType:'text',style:'height:20px',id:'column1',value:'tel',displayMode:'label'}}]}]},{T:1,N:'w2:gBody',A:{style:'',id:'gBody1'},E:[{T:1,N:'w2:row',A:{style:'',id:'row2'},E:[{T:1,N:'w2:column',A:{width:'70',inputType:'text',style:'height:20px',id:'id',value:'',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'70',inputType:'text',style:'height:20px',id:'name',value:'',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'70',inputType:'text',style:'height:20px',id:'tel',value:'',displayMode:'label'}}]}]}]}]}]}]}]})