/*amd /ui/windowContainer/customButton/windowContainer_customButton.xml 4463 46c17555e94cebd96d548372232da4be66d7ab942dc7a44f832ed2cdb36b01d1 */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',E:[{T:1,N:'w2:type',E:[{T:3,text:'DEFAULT'}]},{T:1,N:'w2:buildDate'},{T:1,N:'xf:model',E:[{T:1,N:'w2:dataCollection',A:{baseNode:'map'}},{T:1,N:'w2:workflowCollection'}]},{T:1,N:'script',A:{type:'text/javascript',lazy:'false'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){
	scwin.onpageload = function() {

	};

	scwin.onpageunload = function() {

	};

	scwin.windowIdx = 0;

	/**
	 * WidnowContainer에 윈도우를 동적으로 생성한다.
	 */
	scwin.btn_createWin_onclick = function(e) {
		var windowId = "win" + scwin.windowIdx++;
		var option = {
			title : windowId + "-ti",
			src : "window1.xml",
			windowTitle : windowId + "-Title",
			windowId : windowId,
			openAction : "existWindow",
			frameMode : "wframe",
			fixed : false,
			defaultWidth : "700px",
			defaultHeight : "500px",
			// nameLayerHTML 속성에 정의된 함수를 통해서 Window별 Tab에 사용자가 원하는 HTML를 삽입합니다.
			nameLayerHTML : scwin.nameLayerHtml,
			dataObject : {
				type : "json",
				name : "paramData",
				data : {}
			}
		};
		windowContainer1.createWindow(option);
	};
	
	/**
	 * Window Tab 안에 정의한 Widnow Maximize/Restore 버튼을 클릭 시 발생하는 이벤트 함수
	 */
	scwin.restoreWindowSize = function(e) {
		var windowTitle = e.target.getAttribute("window_title");
		var windowUniqueId = mf_windowContainer1.getUniqueIdByTitle(windowTitle)[0];
		var windowScope = windowContainer1.getWindowByUniqueId(windowUniqueId);
		
		// getWinInfoObj API는 비공개 API 입니다. 
		// 비공개 API의 경우 웹스퀘어 엔진이 업데이트 되면서 스펙이 변경될 수 있으니
		// 업무 화면에서는 사용해서는 안되며 UI 공통에서만 제한적으로 사용해야 합니다.
		var windowObj = windowContainer1.getWinInfoObj(windowUniqueId).window;
		
		if (windowObj.windowInfo.status === "maximized") {
			windowObj.restore();
		} else {
			windowObj.maximize();
		}
		
		// 버튼 클릭시, 탭이 클릭되는 이벤트를 막기 위함
		WebSquare.event.stopPropagation(e); 
	};

	/**
	 * Window별 Tab에 사용자가 원하는 HTML를 삽입합니다.
	 */
	scwin.nameLayerHtml = function(label, fix, close, layerMenu) {
		// 아래는 HTML 코드는 시스템 UI에 맞게 디자인을 변경해서 퍼블리싱해야 합니다.
		return "<button id='button1' style='z-index: 1; border:0px; padding:0px; float:right; margin-right:23px;' window_title ='" + label + "' onclick='" + $p.getFrameId() + "_scwin.restoreWindowSize(window.event)'>▣</button>" + fix + label + close;
	}

}}}]}]},{T:1,N:'body',A:{'ev:onpageload':'scwin.onpageload','ev:onpageunload':'scwin.onpageunload'},E:[{T:1,N:'xf:group',A:{id:'',style:'padding:10px'},E:[{T:1,N:'xf:group',A:{id:'',style:'width: 100%;height: 45px;'},E:[{T:1,N:'w2:textbox',A:{id:'',label:'WindowContainer Custom Button Example',style:'width:50%;height:23px;padding:10px;font-size:18px;font-weight:bold;float:left;'}},{T:1,N:'xf:trigger',A:{'ev:onclick':'scwin.btn_createWin_onclick',id:'btn_createWin',style:'width: 80px;height: 23px;float:right;margin-top: 10px;margin-right: 10px;',type:'button'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'화면 생성'}]}]}]},{T:1,N:'xf:group',A:{id:'grp_group1',style:'width:100%;'},E:[{T:1,N:'w2:windowContainer',A:{sequentialArrangeColNum:'2',verticalArrangeNum:'2',controlIconPosition:'left',windowMaximizeAll:'false',id:'windowContainer1',useStatusMsg:'true',hideTitleOnMaximize:'false',spaInitCount:'0',useNameContainer:'false',useControlIconTitle:'false',tooltipDisplay:'true',style:'position:relative;width:100%;height:518px;',sequentialArrangeRowNum:'2',fixArrangeFullScreen:'false',useFixButton:'false',windowAutoResize:'false',windowMaxNum:'5',useCloseButton:'true',stopMinimizeOnNameLayer:'false',toolbarPosition:'bottom',stopToggleOnLast:'false',horizontalArrangeNum:'2',useCustomMsg:'false',tooltipGroupClass:'false',windowTooltipDisplay:'true',windowMoveType:'overflow'},E:[{T:1,N:'w2:windowToolbar',E:[{T:1,N:'w2:controlIconLayer',E:[{T:1,N:'w2:controlIcon'},{T:1,N:'w2:controlIcon'},{T:1,N:'w2:controlIcon'},{T:1,N:'w2:controlIcon'},{T:1,N:'w2:controlIcon'}]},{T:1,N:'w2:nameLayer'},{T:1,N:'w2:selectedNameLayer'}]}]}]}]}]}]}]})