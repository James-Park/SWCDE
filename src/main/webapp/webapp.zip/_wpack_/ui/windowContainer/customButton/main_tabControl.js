/*amd /ui/windowContainer/customButton/main_tabControl.xml 2796 e2260960b4da6ed92ec5da1b61a8dea7d3d94b3e58586a41b2f0904fd3a67cbc */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',E:[{T:1,N:'w2:type',E:[{T:3,text:'DEFAULT'}]},{T:1,N:'w2:buildDate'},{T:1,N:'xf:model',E:[{T:1,N:'w2:dataCollection',A:{baseNode:'map'}},{T:1,N:'w2:workflowCollection'}]},{T:1,N:'script',A:{type:'text/javascript',lazy:'false'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){
	scwin.onpageload = function() {
	};

	scwin.onpageunload = function() {

	};

	scwin.openMenu = function(menuId, filePath) {
		tac_tabControl1.addTab(menuId, {
			"label" : menuId,
			"title" : "dataObject",
			"openAction" : "exist",
			"closable" : "true"
		}, {
			"src" : filePath,
			"frameMode" : "wframePreload",
			"scope" : true,
			"alwaysDraw" : "true",
			"dataObject" : {
				"type" : "json",
				"name" : "tabParam",
				"data" : {}
			}
		});
		
		tac_tabControl1.setSelectedTabIndex(tac_tabControl1.getTabIndex(menuId));
	};

	scwin.btn_srcDownload_onclick = function(e) {
		window.open('/sample/widgetContainer/customButton/main_tabControl.zip');
	};
	
	scwin.btn_playDownload_onclick = function(e) {
		window.open('/sample/widgetContainer/customButton/widgetContainer_video.gif');
	};
	
}}}]}]},{T:1,N:'body',A:{'ev:onpageload':'scwin.onpageload','ev:onpageunload':'scwin.onpageunload'},E:[{T:1,N:'xf:group',A:{id:'',style:'padding:10px'},E:[{T:1,N:'xf:group',A:{style:'width: 100%;height: 45px;',id:''},E:[{T:1,N:'w2:textbox',A:{style:'width:50%;height:23px;padding:10px;font-size:18px;font-weight:bold;float:left;',id:'',label:'TabControl'}},{T:1,N:'xf:group',A:{id:'',style:'width:45%;height:23px;padding:10px;font-size:18px;font-weight:bold;float:right;'},E:[{T:1,N:'xf:trigger',A:{id:'btn_playDownload',style:'width:106px;height:23px;float:right;',type:'button','ev:onclick':'scwin.btn_playDownload_onclick'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'시연동영상'}]}]},{T:1,N:'xf:trigger',A:{id:'btn_srcDownload',style:'width:106px;height:23px;float:right;margin-right:5px',type:'button','ev:onclick':'scwin.btn_srcDownload_onclick'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'소스 다운로드'}]}]}]}]},{T:1,N:'xf:group',A:{style:'width:100%;height:658px;',id:'grp_group1'},E:[{T:1,N:'w2:tabControl',A:{useTabKeyOnly:'true',id:'tac_tabControl1',useMoveNextTabFocus:'false',useConfirmMessage:'false',confirmTrueAction:'exist',confirmFalseAction:'new',alwaysDraw:'false',style:'width: 100%;height: 650px;'},E:[{T:1,N:'w2:tabs',A:{disabled:'false',style:'width:99px;height:30px;',id:'tabs1',label:'Widget',closable:'false'}},{T:1,N:'w2:content',A:{alwaysDraw:'false',style:'height:600px;',id:'content1',src:'widgetContainer.xml'}}]}]}]}]}]}]})