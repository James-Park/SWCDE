/*amd /ui/util/QRCode_zxing/QRCode_zxing.xml 3684 f5e2c3355fc889a75ec98d72a178902935c4db23a046007e02d5c3014a08d97c */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',E:[{T:1,N:'w2:type',E:[{T:3,text:'DEFAULT'}]},{T:1,N:'w2:buildDate'},{T:1,N:'xf:model',E:[{T:1,N:'w2:dataCollection',A:{baseNode:'map'}},{T:1,N:'w2:workflowCollection'}]},{T:1,N:'script',A:{type:'text/javascript',src:'https://unpkg.com/@zxing/library@latest'}},{T:1,N:'script',A:{type:'text/javascript',lazy:'false'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){
		

	scwin.selectedDeviceId = null;
	scwin.codeReader = null;
	
	/**
	 * https://zxing-js.github.io/library/examples/multi-camera/ 의 예제 화면을 참조해서 웹스퀘어에서 ZXing 라이브러리를 로딩한 예제 입니다.
	 */  
	scwin.onpageload = function() {
		scwin.setQRCode();
	};
	
	scwin.onpageunload = function() {
		
	};


	scwin.btn_start_onclick = function(e) {
		scwin.startQRCode();
	};
	
	scwin.setQRCode = function() {
		var grpVideo = document.getElementById($p.id + "grp_video");
		var video = document.createElement("video");
		video.id = $p.id + "video";
		video.style.width = "100%"; 
		video.style.height = "500px";
		grpVideo.appendChild(video);
		
		scwin.codeReader = new ZXing.BrowserMultiFormatReader();
		console.log('ZXing code reader initialized');

		scwin.codeReader.listVideoInputDevices().then(function(videoInputDevices) {
			if (videoInputDevices.length >= 1) {
				videoInputDevices.forEach(function(element) {
					sbx_selectedDevice.addItem(element.deviceId, element.label);
				})
				sbx_selectedDevice.setSelectedIndex(0);
			}
		}).catch(function(err) {
			console.error(err);
		});	
	};
	
	scwin.startQRCode = function() {
		scwin.codeReader.decodeFromVideoDevice(sbx_selectedDevice.getValue(), $p.id + "video" , function(result, err) {
			if (result) {
				txa_textarea1.setValue(result);
				console.log(result);
			}
			if (err && !(err instanceof ZXing.NotFoundException)) {
				txa_textarea1.setValue(err);
				console.error(err);
			}
		})
		console.log(`Started continous decode from camera with id ${scwin.selectedDeviceId}`);
	};
	
	
	scwin.btn_reset_onclick = function(e) {
		scwin.codeReader.reset();
	};
	
}}}]}]},{T:1,N:'body',A:{'ev:onpageload':'scwin.onpageload','ev:onpageunload':'scwin.onpageunload'},E:[{T:1,N:'xf:group',A:{id:'',style:'padding:10px'},E:[{T:1,N:'xf:group',A:{style:'width: 100%;height: 45px;',id:''},E:[{T:1,N:'w2:textbox',A:{style:'width:50%;height:23px;padding:10px;font-size:18px;font-weight:bold;float:left;',id:'',label:'QR Code Sample (Zxing)'}},{T:1,N:'xf:trigger',A:{'ev:onclick':'scwin.btn_reset_onclick',style:'width: 80px;height: 23px;float:right;margin-top: 10px;margin-right: 10px;',id:'btn_reset',type:'button',nextTabID:''},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'Reset'}]}]},{T:1,N:'xf:trigger',A:{'ev:onclick':'scwin.btn_start_onclick',id:'btn_start',style:'width: 80px;height: 23px;float:right;margin-top: 10px;margin-right: 10px;',type:'button'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'Start'}]}]}]},{T:1,N:'xf:group',A:{style:'width:100%;height:500px;',id:'grp_video'}},{T:1,N:'xf:group',A:{style:'width:100%;height:45px;',id:'sourceSelectPanel',tabIndex:''},E:[{T:1,N:'xf:select1',A:{id:'sbx_selectedDevice',chooseOption:'false',style:'width:218px;height:31px;',submenuSize:'auto',allOption:'false',disabled:'false',direction:'auto',appearance:'minimal',disabledClass:'w2selectbox_disabled'}}]},{T:1,N:'xf:group',A:{style:'width: 100%;height: 100px;',id:''},E:[{T:1,N:'xf:textarea',A:{id:'txa_textarea1',style:'width: 100%;height: 90px;'}}]}]}]}]}]})