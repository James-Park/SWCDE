/*amd /ui/util/FileDownload/download1.xml 3604 579d4f029c4a122c969e8d1fa2a48dc5b5c989617e99ccde67c223bf1fef5080 */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',E:[{T:1,N:'w2:type',E:[{T:3,text:'DEFAULT'}]},{T:1,N:'w2:buildDate'},{T:1,N:'xf:model',E:[{T:1,N:'w2:dataCollection',A:{baseNode:'map'},E:[{T:1,N:'w2:dataList',A:{baseNode:'list',repeatNode:'map',id:'dlt_memberList',saveRemovedData:'true','ev:oncelldatachange':''},E:[{T:1,N:'w2:columnInfo',E:[{T:1,N:'w2:column',A:{id:'id',name:'아이디',dataType:'text'}},{T:1,N:'w2:column',A:{id:'name',name:'성명',dataType:'text'}},{T:1,N:'w2:column',A:{id:'tel',name:'연락처',dataType:'text'}},{T:1,N:'w2:column',A:{id:'region',name:'지역',dataType:'text'}}]},{T:1,N:'w2:data',A:{use:'true'},E:[{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0001'}]},{T:1,N:'name',E:[{T:4,cdata:'홍길동'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2323-4323'}]},{T:1,N:'region',E:[{T:4,cdata:'서울'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0002'}]},{T:1,N:'name',E:[{T:4,cdata:'허균'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2444-2312'}]},{T:1,N:'region',E:[{T:4,cdata:'인천'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0001'}]},{T:1,N:'name',E:[{T:4,cdata:'홍길동1'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2323-4323'}]},{T:1,N:'region',E:[{T:4,cdata:'서울'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0002'}]},{T:1,N:'name',E:[{T:4,cdata:'허균1'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2444-2312'}]},{T:1,N:'region',E:[{T:4,cdata:'인천'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0001'}]},{T:1,N:'name',E:[{T:4,cdata:'홍길동2'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2323-4323'}]},{T:1,N:'region',E:[{T:4,cdata:'서울'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0002'}]},{T:1,N:'name',E:[{T:4,cdata:'허균2'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2444-2312'}]},{T:1,N:'region',E:[{T:4,cdata:'인천'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0001'}]},{T:1,N:'name',E:[{T:4,cdata:'홍길동3'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2323-4323'}]},{T:1,N:'region',E:[{T:4,cdata:'서울'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0002'}]},{T:1,N:'name',E:[{T:4,cdata:'허균3'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2444-2312'}]},{T:1,N:'region',E:[{T:4,cdata:'인천'}]}]}]}]}]},{T:1,N:'w2:workflowCollection'}]},{T:1,N:'script',A:{type:'text/javascript',lazy:'false'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){
	scwin.onpageload = function() {
	};

	scwin.onpageunload = function() {
	};

	scwin.btn_download_onclick = function(e) {
		var fileInfo = {
			"fetchSize" : 1000,
			"filePath" : "",
			"fileName" : "excelDataDownTest",
			"hearderColumns" : ["id", "이름", "e-mail", "전화번호"],
			"dataColumns" : ["", "", "", ""],
			"request" : {
				"id" : "",
				"name" : "",
				"email" : "",
				"tel" : ""
			}
		}
		
		$p.download("/fileDownload", JSON.stringify(fileInfo), "post");
	};

}}}]}]},{T:1,N:'body',A:{'ev:onpageload':'scwin.onpageload','ev:onpageunload':'scwin.onpageunload'},E:[{T:1,N:'xf:group',A:{style:'padding:10px;',id:''},E:[{T:1,N:'xf:group',A:{style:'width: 100%;height:40px;float:left;',id:'',class:''},E:[{T:1,N:'w2:textbox',A:{style:'height: 23px;font-size:20px;float:left;margin-top:5px;margin-left:5px;font-weight: bold',label:'Download',id:''}},{T:1,N:'xf:trigger',A:{id:'btn_download',style:'width:153px;height:23px;float:right;margin-top:10px;',type:'button','ev:onclick':'scwin.btn_download_onclick'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'Download 실행'}]}]}]}]}]}]}]})