/*amd /ui/util/MediaRecorder/MediaRecorderSample.xml 3954 ec362c714d9e5cd061323debc137f19e0d8ae15661e6dfc664750a2eb4f0e49f */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',E:[{T:1,N:'w2:type',E:[{T:3,text:'DEFAULT'}]},{T:1,N:'w2:buildDate'},{T:1,N:'xf:model',E:[{T:1,N:'w2:dataCollection',A:{baseNode:'map'}},{T:1,N:'w2:workflowCollection'}]},{T:1,N:'script',A:{type:'text/javascript',lazy:'false'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){
scwin.onpageload = function() {
    if (typeof navigator.mediaDevices !== "undefined") {
        navigator.mediaDevices.getUserMedia({
            audio : true  // Audio 기능만 사용하도록 audio 속성만 true로 설정함
        }).then(function(stream) {
            // Audio Device가 정상적으로 로딩될 경우 
            btn_record.setDisabled(false); // Record 버튼을 활성화
            btn_stop.setDisabled(true);    // Stop 버튼을 비활성화
            
            var option = {
                audioBitsPerSecond : 128000,   // Audio 인코딩 비트 전송률
                mimeType : "audio/webm"        // Audio 파일 MIME TYPE
            };
            
            // Audio 데이터 녹음을 위한 MediaRecorder 객체 생성
            scwin.recorder = new MediaRecorder(stream, option);  
            // dataavailable 이벤트 설정
            scwin.recorder.addEventListener("dataavailable", scwin.onRecordingReady); 
        }).catch(function(ex) {
            // Audio Device가 로딩 과정에서 에러 발생
            console.error(ex); 
        });
    } else {
        console.error("navigator.mediaDevices에 접근할 수 없습니다.");
    }
};

/**
 * Record 버튼 클릭 시
 */
scwin.btn_record_onclick = function(e) {
    btn_record.setDisabled(true);
    btn_stop.setDisabled(false);
    scwin.recorder.start(); // MediaRecorder 객체를 이용한 녹음 시작
};

/**
 * Stop 버튼 클릭 시
 */
scwin.btn_stop_onclick = function(e) {
    btn_record.setDisabled(false);
    btn_stop.setDisabled(true);
    scwin.recorder.stop();  // MediaRecorder 객체를 이용한 녹음 종료
};

/**
 * dataavailable 이벤트 발생 시 (녹음 종료 시 발생함)
 */
scwin.onRecordingReady = function(e) { 
	// 녹음된 데이터 객체를 가리키는 URL을 생성해서 Audio 객체의 src에 세팅함	
    aud_audio1.src = URL.createObjectURL(e.data);  
    aud_audio1.play();
};

scwin.onpageunload = function() {
	// 페이지가 unload될 때 녹음된 데이터 객체를 가리키는 URL 해제함
	URL.revokeObjectURL(aud_audio1.src);
};
}}}]}]},{T:1,N:'body',A:{'ev:onpageload':'scwin.onpageload','ev:onpageunload':'scwin.onpageunload'},E:[{T:1,N:'xf:group',A:{id:'',style:'padding : 10px'},E:[{T:1,N:'xf:group',A:{style:'width:100%;height:61px;',id:''},E:[{T:1,N:'w2:textbox',A:{style:'width:50%;height:23px;padding:10px;font-size:24px;font-weight:bold;float:left;font-size-adjust:0;border-bottom:;border-style:solid;border:;;border-top-width:0px;border-right-width:0px;border-bottom-width:1px;border-left-width:0px;',id:'',label:'Media Recorder Sample'}}]},{T:1,N:'xf:group',A:{style:'width:100%;height:200px;',id:'grp_group1'},E:[{T:1,N:'xf:group',A:{tagname:'',style:'width: 100%;height: 50px;',id:''},E:[{T:1,N:'xf:trigger',A:{style:'width:151px;height:42px;font-size:18px;font-size-adjust:0;',id:'btn_record',type:'button','ev:onclick':'scwin.btn_record_onclick'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'Record'}]}]},{T:1,N:'xf:trigger',A:{style:'width:151px;height:42px;font-size:18px;font-size-adjust:0;margin-left:10px;',id:'btn_stop',type:'button','ev:onclick':'scwin.btn_stop_onclick'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'Stop'}]}]}]},{T:1,N:'xf:group',A:{tagname:'',style:'width: 100%;height: 100px;',userData2:'',id:''},E:[{T:1,N:'audio',A:{controls:'',style:'width:452px;height:98px;',id:'aud_audio1'}}]}]}]}]}]}]})