/*amd /ui/gridView/clickEventController/grd_clickEventController2.xml 6236 a98567e95faad885363f9fc97dfa1c9555c3012abde8ca4dc18250a8ad160e66 */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',E:[{T:1,N:'w2:type',E:[{T:3,text:'DEFAULT'}]},{T:1,N:'w2:buildDate'},{T:1,N:'xf:model',E:[{T:1,N:'w2:dataCollection',A:{baseNode:'map'},E:[{T:1,N:'w2:dataList',A:{baseNode:'list',repeatNode:'map',id:'dlt_memberList',saveRemovedData:'true','ev:oncelldatachange':''},E:[{T:1,N:'w2:columnInfo',E:[{T:1,N:'w2:column',A:{id:'id',name:'아이디',dataType:'text'}},{T:1,N:'w2:column',A:{id:'name',name:'성명',dataType:'text'}},{T:1,N:'w2:column',A:{id:'tel',name:'연락처',dataType:'text'}},{T:1,N:'w2:column',A:{id:'region',name:'지역',dataType:'text'}}]},{T:1,N:'w2:data',A:{use:'true'},E:[{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0001'}]},{T:1,N:'name',E:[{T:4,cdata:'홍길동'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2323-4323'}]},{T:1,N:'region',E:[{T:4,cdata:'서울'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0002'}]},{T:1,N:'name',E:[{T:4,cdata:'허균'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2444-2312'}]},{T:1,N:'region',E:[{T:4,cdata:'인천'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0001'}]},{T:1,N:'name',E:[{T:4,cdata:'홍길동1'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2323-4323'}]},{T:1,N:'region',E:[{T:4,cdata:'서울'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0002'}]},{T:1,N:'name',E:[{T:4,cdata:'허균1'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2444-2312'}]},{T:1,N:'region',E:[{T:4,cdata:'인천'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0001'}]},{T:1,N:'name',E:[{T:4,cdata:'홍길동2'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2323-4323'}]},{T:1,N:'region',E:[{T:4,cdata:'서울'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0002'}]},{T:1,N:'name',E:[{T:4,cdata:'허균2'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2444-2312'}]},{T:1,N:'region',E:[{T:4,cdata:'인천'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0001'}]},{T:1,N:'name',E:[{T:4,cdata:'홍길동3'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2323-4323'}]},{T:1,N:'region',E:[{T:4,cdata:'서울'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0002'}]},{T:1,N:'name',E:[{T:4,cdata:'허균3'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2444-2312'}]},{T:1,N:'region',E:[{T:4,cdata:'인천'}]}]}]}]}]},{T:1,N:'w2:workflowCollection'}]},{T:1,N:'script',A:{type:'text/javascript',lazy:'false'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){
scwin.onpageload = function () {
	// config.xml의 <initScript>와 <wframe><initScript>에 아래의 코드를 추가하면 모든 화면에 Click 이벤트 제어가 적용됨
	// 특정 화면에만 적용하기 원할 경우 config.xml에 추가하지 말고 "com.setClickEvent($p);"를 onpageload 이벤트에서 실행하면 됨됨
	// com.setClickEvent($p);
};

scwin.grd_gridView1_oncellclick = function(row,col,colId) {
	scwin.writeLog("[grd_gridView1_oncellclick] row : " + row + ", col : " + col + ", colId : " + colId);
	//alert("grd_gridView1_oncellclick");
};

scwin.grd_gridView1_oncelldblclick = function(row,col,colId) {
	scwin.writeLog("[grd_gridView1_oncelldblclick] row : " + row + ", col : " + col + ", colId : " + colId);
	//alert("grd_gridView1_oncelldblclick");
};

scwin.btn_trigger_onclick = function(e) {
	scwin.writeLog("[btn_trigger_onclick] Click Event");
	//alert("btn_trigger_onclick");
};

scwin.btn_trigger_ondblclick = function(e) {
	scwin.writeLog("[btn_trigger_ondblclick] DblClick Event");
	//alert("btn_trigger_ondblclick");
};

scwin.writeLog = function(log) {
	txa_log.setValue("[" + $p.getCurrentServerDate("yyyy-MM-dd HH:mm:ss") + "]" + log + "\n" + txa_log.getValue());
};


}}}]}]},{T:1,N:'body',A:{'ev:onpageload':'scwin.onpageload'},E:[{T:1,N:'xf:group',A:{style:'padding:10px;',id:'grp_content'},E:[{T:1,N:'xf:group',A:{style:'width: 100%;height:40px;float:left;',id:'',class:''},E:[{T:1,N:'w2:textbox',A:{style:'height: 23px;font-size:20px;float:left;margin-top:5px;margin-left:5px;font-weight: bold',label:'GridView click & dbClick Event 제어 예제',id:''}},{T:1,N:'xf:trigger',A:{id:'btn_trigger',style:'width:216px;height:23px;float:right;margin-top:10px;margin-right:10px;',type:'button','ev:onclick':'scwin.btn_trigger_onclick','ev:ondblclick':'scwin.btn_trigger_ondblclick'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'Trigger 이벤트 Click 테스트1'}]}]}]},{T:1,N:'w2:gridView',A:{id:'grd_gridView1',ignoreToggleOnDisabled:'false',useShiftKey:'true',style:'width:100%;height:134px;',scrollByColumn:'false',defaultCellHeight:'20',scrollByColumnAdaptive:'false',summaryAuto:'false',summaryOnlyAuto:'false',applyAllColumnStyle:'false',dataList:'data:dlt_memberList',ignoreCellClick:'false',autoFit:'allColumn','ev:oncellclick':'scwin.grd_gridView1_oncellclick','ev:oncelldblclick':'scwin.grd_gridView1_oncelldblclick'},E:[{T:1,N:'w2:caption',A:{style:'',id:'caption1',value:'this is a grid caption.'}},{T:1,N:'w2:header',A:{style:'',id:'header1'},E:[{T:1,N:'w2:row',A:{style:'',id:'row1'},E:[{T:1,N:'w2:column',A:{width:'135',inputType:'text',style:'',id:'column7',value:'아이디',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'113',inputType:'text',style:'',id:'column5',value:'성명',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'114',inputType:'text',style:'',id:'column3',value:'연락처',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'129',inputType:'text',style:'',id:'column1',value:'지역',blockSelect:'false',displayMode:'label'}}]}]},{T:1,N:'w2:gBody',A:{style:'',id:'gBody1'},E:[{T:1,N:'w2:row',A:{style:'',id:'row2'},E:[{T:1,N:'w2:column',A:{width:'135',inputType:'text',style:'',id:'id',value:'',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'113',inputType:'text',style:'',id:'name',value:'',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'114',inputType:'text',style:'',id:'tel',value:'',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'129',inputType:'text',style:'',id:'region',value:'',blockSelect:'false',displayMode:'label'}}]}]}]},{T:1,N:'xf:textarea',A:{id:'txa_log',style:'width: 100%;height: 100px;'}}]}]}]}]})