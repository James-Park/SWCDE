/*amd /ui/gridView/scrollControl/gridView_scrollControl_For_Supporting_MouseWheel_IE.xml 5431 28fbe18afc1981bfbcc70436bb521a1a15d4133870aaf46432c88e1517b43147 */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',E:[{T:1,N:'w2:type',E:[{T:3,text:'DEFAULT'}]},{T:1,N:'w2:buildDate'},{T:1,N:'xf:model',E:[{T:1,N:'w2:dataCollection',A:{baseNode:'map'},E:[{T:1,N:'w2:dataList',A:{baseNode:'list',repeatNode:'map',id:'dataList1',saveRemovedData:'true'},E:[{T:1,N:'w2:columnInfo',E:[{T:1,N:'w2:column',A:{id:'amount',name:'금액',dataType:'number'}},{T:1,N:'w2:column',A:{id:'customer_code',name:'고객코드',dataType:'text'}},{T:1,N:'w2:column',A:{id:'end_date',name:'종료시간',dataType:'date'}},{T:1,N:'w2:column',A:{id:'from_date',name:'시작시간',dataType:'date'}},{T:1,N:'w2:column',A:{id:'model_code',name:'모델코드',dataType:'text'}},{T:1,N:'w2:column',A:{id:'national_code',name:'국가코드',dataType:'text'}},{T:1,N:'w2:column',A:{id:'national_word',name:'국가어',dataType:'text'}},{T:1,N:'w2:column',A:{id:'order_no',name:'정렬번호',dataType:'text'}},{T:1,N:'w2:column',A:{id:'order_type',name:'정렬구분',dataType:'text'}}]}]}]},{T:1,N:'w2:workflowCollection'},{T:1,N:'xf:submission',A:{id:'submission1',ref:'',target:'data:json,{"id":"dataList1","action":"append","key":"jsondata"}',action:'sJsonData.json',method:'get',mediatype:'application/json',encoding:'UTF-8',instance:'',replace:'',errorHandler:'',customHandler:'',mode:'asynchronous',processMsg:'','ev:submit':'','ev:submitdone':'scwin.submission1_submitdone','ev:submiterror':'',abortTrigger:''}}]},{T:1,N:'script',A:{type:'text/javascript',lazy:'false'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){scwin.top = 0;
scwin.maxTop = 0;
scwin.ROW_PAGE_HEIGHT = 80;
scwin.ROW_HEIGHT = 20;

scwin.onpageload = function () {
	$p.executeSubmission("submission1");
};

scwin.onpageunload = function () {

};

scwin.btn_moveTop_onclick = function (e) {
	if (scwin.top >= scwin.ROW_PAGE_HEIGHT) {
		scwin.top -= scwin.ROW_PAGE_HEIGHT;
	}
	grd_custAmt.setScrollTop(scwin.top);
};

scwin.btn_moveBottom_onclick = function (e) {
	if (scwin.maxTop > scwin.top) {
		scwin.top += scwin.ROW_PAGE_HEIGHT;
	}
	grd_custAmt.setScrollTop(scwin.top);
};

scwin.submission1_submitdone = function (e) {
	var allRowHeight = dataList1.getRowCount() * scwin.ROW_HEIGHT;
	scwin.maxTop = allRowHeight - (allRowHeight % scwin.ROW_PAGE_HEIGHT);
};

scwin.grd_custAmt_onscrolly = function () {
	//console.log("scwin.grd_custAmt_onscrolly");
};

}}}]},{T:1,N:'style',A:{type:'text/css'},E:[{T:4,cdata:'#grd_custAmt_scrollY_div{opacity:0}'}]}]},{T:1,N:'body',A:{'ev:onpageload':'scwin.onpageload','ev:onpageunload':'scwin.onpageunload'},E:[{T:1,N:'xf:group',A:{style:'position:relative;height:108px;display:inline-block;',id:''},E:[{T:1,N:'w2:gridView',A:{syncScroll:'false',scrollByColumnAdaptive:'',summaryAuto:'false',useShiftKey:'true',scrollByColumn:'',summaryOnlyAuto:'false',defaultCellHeight:'20',applyAllColumnStyle:'false',overflowX:'',overflowY:'',dataList:'data:dataList1',style:'width:360px;height:108px;',ignoreCellClick:'false',id:'grd_custAmt',ignoreToggleOnDisabled:'false','ev:onscrolly':'scwin.grd_custAmt_onscrolly',wheelRows:'',wheelStop:'',fastScroll:'',autoFit:'allColumn'},E:[{T:1,N:'w2:caption',A:{style:'',id:'caption2',value:'this is a grid caption.'}},{T:1,N:'w2:header',A:{style:'',id:'header2'},E:[{T:1,N:'w2:row',A:{style:'',id:'row3'},E:[{T:1,N:'w2:column',A:{footerDiv:'false',removeBorderStyle:'false',width:'70',inputType:'text',style:'',id:'column19',value:'금액',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{footerDiv:'false',removeBorderStyle:'false',width:'76',inputType:'text',style:'',id:'column17',value:'고객코드',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{footerDiv:'false',removeBorderStyle:'false',width:'78',inputType:'text',style:'',id:'column15',value:'종료시간',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{footerDiv:'false',removeBorderStyle:'false',width:'80',inputType:'text',style:'',id:'column13',value:'시작시간',blockSelect:'false',displayMode:'label'}}]}]},{T:1,N:'w2:gBody',A:{style:'',id:'gBody2'},E:[{T:1,N:'w2:row',A:{style:'',id:'row4'},E:[{T:1,N:'w2:column',A:{footerDiv:'false',removeBorderStyle:'false',width:'70',inputType:'text',style:'',id:'amount',value:'',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{footerDiv:'false',removeBorderStyle:'false',width:'76',inputType:'text',style:'',id:'customer_code',value:'',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{footerDiv:'false',removeBorderStyle:'false',width:'78',inputType:'text',style:'',id:'end_date',value:'',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{footerDiv:'false',removeBorderStyle:'false',width:'80',inputType:'text',style:'',id:'from_date',value:'',blockSelect:'false',displayMode:'label'}}]}]}]},{T:1,N:'xf:group',A:{style:'position:absolute;top:0px;right:-2px;height:108px;width:21px;',id:''},E:[{T:1,N:'xf:trigger',A:{style:'width:21px;height: 54px;',id:'btn_moveTop',type:'button','ev:onclick':'scwin.btn_moveTop_onclick'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'▲'}]}]},{T:1,N:'xf:trigger',A:{type:'button',style:'width:21px;height: 54px;',id:'btn_moveBottom','ev:onclick':'scwin.btn_moveBottom_onclick'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'▼'}]}]}]}]}]}]}]})