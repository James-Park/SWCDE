/*amd /ui/gridView/customFormatter/grd_customFormatter2.xml 5417 c8cc005306b904e652b055faeefa92064e9677105bebd65dae305670375183dc */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',E:[{T:1,N:'w2:type',E:[{T:3,text:'DEFAULT'}]},{T:1,N:'w2:buildDate'},{T:1,N:'xf:model',E:[{T:1,N:'w2:dataCollection',A:{baseNode:'map'},E:[{T:1,N:'w2:dataList',A:{baseNode:'list',repeatNode:'map',id:'dlt_memberList',saveRemovedData:'true','ev:oncelldatachange':''},E:[{T:1,N:'w2:columnInfo',E:[{T:1,N:'w2:column',A:{id:'id',name:'아이디',dataType:'text'}},{T:1,N:'w2:column',A:{id:'name',name:'성명',dataType:'text'}},{T:1,N:'w2:column',A:{id:'tel',name:'연락처',dataType:'text'}},{T:1,N:'w2:column',A:{id:'region',name:'지역',dataType:'text'}}]},{T:1,N:'w2:data',A:{use:'true'},E:[{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0001'}]},{T:1,N:'name',E:[{T:4,cdata:'홍길동'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2323-4323'}]},{T:1,N:'region',E:[{T:4,cdata:'서울'}]}]},{T:1,N:'w2:row',E:[{T:1,N:'id',E:[{T:4,cdata:'P0002'}]},{T:1,N:'name',E:[{T:4,cdata:'허균'}]},{T:1,N:'tel',E:[{T:4,cdata:'010-2444-2312'}]},{T:1,N:'region',E:[{T:4,cdata:'인천'}]}]}]}]}]},{T:1,N:'w2:workflowCollection'}]},{T:1,N:'script',A:{type:'text/javascript',lazy:'false'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){
	scwin.onpageload = function() {
	};

	scwin.onpageunload = function() {
	};
	
	scwin.customFormatter1 = function(data, formattedData, row, col) {
		var id = dlt_memberList.getCellData(row, "id");
		var name = dlt_memberList.getCellData(row, "name");

		if (row % 2 === 1) { 
			grd_gridView1.setCellBackgroundColor(row, "btn1", "gray");
			grd_gridView1.setDisabled("cell", row, "btn1", false);
		} else {
			grd_gridView1.setCellBackgroundColor(row, "btn1", "white");
			
			grd_gridView1.setDisabled("cell", row, "btn1", true);
		}
	};
	
	scwin.grd_gridView1_oncelldblclick = function(row,col,colId) {
		if (colId === "btn1") {
			alert("click");
		}
	};
	
}}}]}]},{T:1,N:'body',A:{'ev:onpageload':'scwin.onpageload','ev:onpageunload':'scwin.onpageunload'},E:[{T:1,N:'xf:group',A:{style:'height:136px;padding:10px;',id:''},E:[{T:1,N:'xf:group',A:{style:'width: 100%;height:40px;float:left;',id:'',class:''},E:[{T:1,N:'w2:textbox',A:{style:'height: 23px;font-size:20px;float:left;margin-top:5px;margin-left:5px;font-weight: bold',label:'GridView DisplayFormatter 예제',id:''}}]},{T:1,N:'w2:gridView',A:{id:'grd_gridView1',ignoreToggleOnDisabled:'false',useShiftKey:'true',style:'width: 100%;height: 150px;',scrollByColumn:'false',defaultCellHeight:'20',scrollByColumnAdaptive:'false',summaryAuto:'false',summaryOnlyAuto:'false',applyAllColumnStyle:'false',dataList:'data:dlt_memberList',ignoreCellClick:'false',autoFit:'allColumn','ev:oncellclick':'','ev:onrightbuttonclick':'scwin.grd_gridView1_onrightbuttonclick','ev:oncelldblclick':'scwin.grd_gridView1_oncelldblclick'},E:[{T:1,N:'w2:caption',A:{style:'',id:'caption1',value:'this is a grid caption.'}},{T:1,N:'w2:header',A:{style:'',id:'header1'},E:[{T:1,N:'w2:row',A:{style:'',id:'row1'},E:[{T:1,N:'w2:column',A:{width:'70',inputType:'text',style:'height:20px;',id:'column7',value:'아이디',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'70',inputType:'text',style:'height:20px;',id:'column5',value:'성명',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'70',inputType:'text',style:'height:20px;',id:'column3',value:'연락처',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'70',inputType:'text',style:'height:20px;',id:'column1',value:'지역',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'209',inputType:'text',style:'height:20px;',id:'column8',value:'expression',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'252',inputType:'text',style:'height:20px;',id:'column10',value:'customFormatter',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{removeBorderStyle:'false',width:'70',inputType:'text',style:'height:20px',id:'column12',value:'버튼',blockSelect:'false',displayMode:'label'}}]}]},{T:1,N:'w2:gBody',A:{style:'',id:'gBody1'},E:[{T:1,N:'w2:row',A:{style:'',id:'row2'},E:[{T:1,N:'w2:column',A:{width:'70',inputType:'text',style:'height:20px;',id:'id',value:'',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'70',inputType:'text',style:'height:20px;',id:'name',value:'',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'70',inputType:'text',style:'height:20px;',id:'tel',value:'',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'70',inputType:'text',style:'height:20px;',id:'region',value:'',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'209',inputType:'expression',style:'height:20px;',id:'column9',value:'',blockSelect:'false',displayMode:'label',expression:'display(\'name\') + " : " + display(\'tel\')',textAlign:'left'}},{T:1,N:'w2:column',A:{width:'252',inputType:'text',style:'height:20px;',id:'column11',value:'',blockSelect:'false',displayMode:'label',displayFormatter:'',customFormatter:'scwin.customFormatter1',textAlign:'left'}},{T:1,N:'w2:column',A:{removeBorderStyle:'false',width:'70',inputType:'text',style:'height:20px',id:'btn1',value:'이미지',blockSelect:'false',displayMode:'label',imageSrc:'',imageWidth:'0'}}]}]}]}]}]}]}]})