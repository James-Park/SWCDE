/*amd /ui/dataCollection/colunmControl/singleRow_Data1.xml 4650 70a431668e109976cc6ffa07108c5436f6367d04a2c2b061ef43baa92657ce9d */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',E:[{T:1,N:'w2:type',E:[{T:3,text:'DEFAULT'}]},{T:1,N:'w2:buildDate'},{T:1,N:'xf:model',E:[{T:1,N:'w2:dataCollection',A:{baseNode:'map'},E:[{T:1,N:'w2:dataList',A:{baseNode:'list',id:'dlt_memberList','ev:oncelldatachange':'',repeatNode:'map',saveRemovedData:'true',initRowPosition:'0'},E:[{T:1,N:'w2:columnInfo',E:[{T:1,N:'w2:column',A:{id:'id',name:'아이디',dataType:'text'}},{T:1,N:'w2:column',A:{id:'name',name:'성명',dataType:'text'}},{T:1,N:'w2:column',A:{id:'tel',name:'연락처',dataType:'text'}},{T:1,N:'w2:column',A:{id:'region',name:'지역',dataType:'text'}}]}]}]},{T:1,N:'w2:workflowCollection'}]},{T:1,N:'script',A:{type:'text/javascript',src:'common.js',scopeExternal:'true',scopeVariable:'com'}},{T:1,N:'script',A:{type:'text/javascript',lazy:'false'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){scwin.onpageload = function () {
	// 1건의 데이터로 Array 형태로 정의해서 세팅해야 합니다.
	var jsonData = [
		{ "id": "P0001", "name": "홍길동", "tel": "010-2323-4323", "region": "서울" }
	];
	dlt_memberList.setJSON(jsonData);
};

scwin.btn_insertColumn_onclick = function (e) {
	// DataList에 컬럼을 추가합니다.
	com.insertColumn(dlt_memberList, "email", { name: "이메일", dataType: "text" });
	dlt_memberList.setCellData(0, "email", "gdhong@test.com");
	console.log("## DataList에 컬럼을 추가 ###################");
	console.log(dlt_memberList.getAllJSON());
};

scwin.btn_removeColumn_onclick = function (e) {
	// DataList에 컬럼을 삭제합니다.
	com.removeColumn(dlt_memberList, "email");
	console.log("## DataList에 컬럼을 삭제 ###################");
	console.log(dlt_memberList.getAllJSON());
};

}}}]}]},{T:1,N:'body',A:{'ev:onpageload':'scwin.onpageload'},E:[{T:1,N:'xf:group',A:{style:'padding:10px;',id:''},E:[{T:1,N:'xf:group',A:{id:'',style:'width: 100%;height: 45px;'},E:[{T:1,N:'w2:textbox',A:{id:'',label:'Single Row Data',style:'width:50%;height:23px;padding:10px;font-size:18px;font-weight:bold;float:left;'}},{T:1,N:'xf:trigger',A:{'ev:onclick':'scwin.btn_removeColumn_onclick',id:'btn_removeColumn',style:'width:80px;height:26px;float:right;margin-top:10px;margin-right:10px;',type:'button'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'컬럼 삭제'}]}]},{T:1,N:'xf:trigger',A:{'ev:onclick':'scwin.btn_insertColumn_onclick',id:'btn_insertColumn',style:'width:80px;height:26px;float:right;margin-top:10px;margin-right:10px;',type:'button'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'컬럼 추가'}]}]}]},{T:1,N:'xf:group',A:{tagname:'table',style:'width:100%;',id:'',class:'w2tb'},E:[{T:1,N:'w2:attributes',E:[{T:1,N:'w2:summary'}]},{T:1,N:'xf:group',A:{tagname:'caption'}},{T:1,N:'xf:group',A:{tagname:'colgroup'},E:[{T:1,N:'xf:group',A:{tagname:'col',style:'width:25.00%;'}},{T:1,N:'xf:group',A:{tagname:'col',style:'width:25.00%'}},{T:1,N:'xf:group',A:{tagname:'col',style:'width:25.00%;'}},{T:1,N:'xf:group',A:{tagname:'col',style:'width:25.00%'}}]},{T:1,N:'xf:group',A:{tagname:'tr',style:''},E:[{T:1,N:'xf:group',A:{tagname:'th',style:'',class:'w2tb_th'},E:[{T:3,text:'아이디'},{T:1,N:'w2:attributes',E:[{T:1,N:'w2:scope',E:[{T:3,text:'row'}]}]}]},{T:1,N:'xf:group',A:{tagname:'td',style:'',class:'w2tb_td'},E:[{T:1,N:'xf:input',A:{adjustMaxLength:'false',id:'',style:'width: 95%;height: 21px;',ref:'data:dlt_memberList.id'}}]},{T:1,N:'xf:group',A:{tagname:'th',style:'',class:'w2tb_th'},E:[{T:3,text:'연락처'},{T:1,N:'w2:attributes',E:[{T:1,N:'w2:scope',E:[{T:3,text:'row'}]}]}]},{T:1,N:'xf:group',A:{tagname:'td',style:'',class:'w2tb_td'},E:[{T:1,N:'xf:input',A:{adjustMaxLength:'false',id:'',style:'width: 95%;height: 21px;',ref:'data:dlt_memberList.tel'}}]}]},{T:1,N:'xf:group',A:{tagname:'tr',style:''},E:[{T:1,N:'xf:group',A:{tagname:'th',style:'',class:'w2tb_th'},E:[{T:3,text:'성명'},{T:1,N:'w2:attributes',E:[{T:1,N:'w2:scope',E:[{T:3,text:'row'}]}]}]},{T:1,N:'xf:group',A:{tagname:'td',style:'',class:'w2tb_td'},E:[{T:1,N:'xf:input',A:{adjustMaxLength:'false',id:'',style:'width: 95%;height: 21px;',ref:'data:dlt_memberList.name'}}]},{T:1,N:'xf:group',A:{tagname:'th',style:'',class:'w2tb_th'},E:[{T:3,text:'지역'},{T:1,N:'w2:attributes',E:[{T:1,N:'w2:scope',E:[{T:3,text:'row'}]}]}]},{T:1,N:'xf:group',A:{tagname:'td',style:'',class:'w2tb_td'},E:[{T:1,N:'xf:input',A:{adjustMaxLength:'false',id:'',style:'width: 95%;height: 21px;',ref:'data:dlt_memberList.region'}}]}]}]}]}]}]}]})