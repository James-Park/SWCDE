/*amd /ui/dataCollection/colunmControl/multiRow_Data.xml 4932 94ab10331a471091d9e4f1cc01f8d367097a0fbadcf95c6d47d06fafc4630cb7 */
define({declaration:{A:{version:'1.0',encoding:'UTF-8'}},E:[{T:1,N:'html',A:{xmlns:'http://www.w3.org/1999/xhtml','xmlns:ev':'http://www.w3.org/2001/xml-events','xmlns:w2':'http://www.inswave.com/websquare','xmlns:xf':'http://www.w3.org/2002/xforms'},E:[{T:1,N:'head',E:[{T:1,N:'w2:type',E:[{T:3,text:'DEFAULT'}]},{T:1,N:'w2:buildDate'},{T:1,N:'xf:model',E:[{T:1,N:'w2:dataCollection',A:{baseNode:'map'},E:[{T:1,N:'w2:dataList',A:{baseNode:'list',repeatNode:'map',id:'dlt_memberList',saveRemovedData:'true','ev:oncelldatachange':''},E:[{T:1,N:'w2:columnInfo',E:[{T:1,N:'w2:column',A:{id:'id',name:'아이디',dataType:'text'}},{T:1,N:'w2:column',A:{id:'name',name:'성명',dataType:'text'}},{T:1,N:'w2:column',A:{id:'tel',name:'연락처',dataType:'text'}},{T:1,N:'w2:column',A:{id:'region',name:'지역',dataType:'text'}}]}]}]},{T:1,N:'w2:workflowCollection'}]},{T:1,N:'script',A:{type:'text/javascript',src:'common.js',scopeExternal:'true',scopeVariable:'com'}},{T:1,N:'script',A:{type:'text/javascript',lazy:'false'},E:[{T:4,cdata:function(scopeObj){with(scopeObj){
scwin.onpageload = function () {
	// 테스트를 위해서 JSON 데이터를 직접 DataList에서 세팅합니다.
	// DataList(dlt_memberList)에 Array 형태로 데이터를 세팅해야 하기 때문에 배열로 데이터로 정의해야 합니다.
	var jsonData = [
		{ "id": "P0001", "name": "홍길동", "tel": "010-2323-4323", "region": "서울" },
		{ "id": "P0002", "name": "김성현", "tel": "010-5343-4323", "region": "인천" },
		{ "id": "P0003", "name": "박만수", "tel": "010-5322-4323", "region": "김포" },
		{ "id": "P0004", "name": "김영호", "tel": "010-1231-7343", "region": "부천" },
		{ "id": "P0005", "name": "박기영", "tel": "010-5343-6534", "region": "서울" }
	];
	dlt_memberList.setJSON(jsonData);
};

scwin.onpageunload = function () {
};

scwin.btn_insertColumn_onclick = function (e) {
	// DataList에 컬럼을 추가합니다.
	com.insertColumn(dlt_memberList, "email", { name: "이메일", dataType: "text" });
	dlt_memberList.setCellData(0, "email", "gdhong@test.com");
	console.log("## DataList에 컬럼을 추가 ###################");
	console.log(dlt_memberList.getAllJSON());
};

scwin.btn_removeColumn_onclick = function (e) {
	// DataList에 컬럼을 삭제합니다.
	com.removeColumn(dlt_memberList, "email");
	console.log("## DataList에 컬럼을 삭제 ###################");
	console.log(dlt_memberList.getAllJSON());
};

}}}]}]},{T:1,N:'body',A:{'ev:onpageload':'scwin.onpageload','ev:onpageunload':'scwin.onpageunload'},E:[{T:1,N:'xf:group',A:{style:'padding:10px;',id:''},E:[{T:1,N:'xf:group',A:{id:'',style:'width: 100%;height: 45px;'},E:[{T:1,N:'w2:textbox',A:{id:'',label:'Multi Row Data',style:'width:50%;height:23px;padding:10px;font-size:18px;font-weight:bold;float:left;'}},{T:1,N:'xf:trigger',A:{'ev:onclick':'scwin.btn_removeColumn_onclick',id:'btn_removeColumn',style:'width:80px;height:26px;float:right;margin-top:10px;margin-right:10px;',type:'button'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'컬럼 삭제'}]}]},{T:1,N:'xf:trigger',A:{'ev:onclick':'scwin.btn_insertColumn_onclick',id:'btn_insertColumn',style:'width:80px;height:26px;float:right;margin-top:10px;margin-right:10px;',type:'button'},E:[{T:1,N:'xf:label',E:[{T:4,cdata:'컬럼 추가'}]}]}]},{T:1,N:'w2:gridView',A:{id:'grd_gridView1',ignoreToggleOnDisabled:'false',useShiftKey:'true',style:'width:100%;height:134px;',scrollByColumn:'false',defaultCellHeight:'20',scrollByColumnAdaptive:'false',summaryAuto:'false',summaryOnlyAuto:'false',applyAllColumnStyle:'false',dataList:'data:dlt_memberList',ignoreCellClick:'false',autoFit:'allColumn'},E:[{T:1,N:'w2:caption',A:{style:'',id:'caption1',value:'this is a grid caption.'}},{T:1,N:'w2:header',A:{style:'',id:'header1'},E:[{T:1,N:'w2:row',A:{style:'',id:'row1'},E:[{T:1,N:'w2:column',A:{width:'135',inputType:'text',style:'',id:'column7',value:'아이디',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'113',inputType:'text',style:'',id:'column5',value:'성명',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'114',inputType:'text',style:'',id:'column3',value:'연락처',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'129',inputType:'text',style:'',id:'column1',value:'지역',blockSelect:'false',displayMode:'label'}}]}]},{T:1,N:'w2:gBody',A:{style:'',id:'gBody1'},E:[{T:1,N:'w2:row',A:{style:'',id:'row2'},E:[{T:1,N:'w2:column',A:{width:'135',inputType:'text',style:'',id:'id',value:'',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'113',inputType:'text',style:'',id:'name',value:'',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'114',inputType:'text',style:'',id:'tel',value:'',blockSelect:'false',displayMode:'label'}},{T:1,N:'w2:column',A:{width:'129',inputType:'text',style:'',id:'region',value:'',blockSelect:'false',displayMode:'label'}}]}]}]}]}]}]}]})